"""
main.py - FastAPI application for TenderBot AI.

End-to-end flow
---------------
 1. POST /scan-tenders          scraper_agent finds + ranks tenders for a vendor (optional monitor).
 2. POST /analyze-tender        analyzer_agent reads the tender, diffs it against the vendor's
                                documents, stores the gap report and WhatsApps the checklist.
 3. POST /request-submit-approval  (only when documents are complete) creates an ApprovalRequest,
                                phones the vendor (Twilio Voice, Marathi/English) AND sends a
                                WhatsApp YES/NO prompt.
 4a. POST /whatsapp-webhook     vendor replies YES/NO on WhatsApp.
 4b. POST /voice-response       vendor presses 1/2 or says yes/no on the call.
     Both call `apply_decision`, which is idempotent: the first valid answer wins, expired
     requests are never executed, and YES queues `run_submission_flow` in the background.
 5. POST /get-tax-advice        tax_agent: GST, ITC saving strategies, invoice draft, CA pack.

Run:  uvicorn main:app --host 0.0.0.0 --port 8000
"""
from __future__ import annotations

import asyncio
import logging
from contextlib import asynccontextmanager
from datetime import datetime, timedelta
from typing import Literal, Optional

from fastapi import BackgroundTasks, Depends, FastAPI, HTTPException, Request, Response
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from agents.analyzer_agent import (
    AnalysisInputError,
    AnalyzerAgent,
    GapReport,
    TenderSummary,
    VendorProfile,
)
from agents.communication_agent import (
    CommunicationAgent,
    CommunicationError,
    Decision,
    bilingual,
    parse_decision,
)
from agents.scraper_agent import AssistedSubmitter, ScraperAgent
from agents.tax_agent import TaxAdviceRequest, TaxAdviceResponse, TaxAgent
from config import configure_logging, format_inr, normalize_phone, now_ist, settings, to_naive_ist
from database import (
    ApprovalRequest,
    ApprovalStatus,
    TaxRecord,
    Tender,
    TenderAnalysis,
    Vendor,
    get_db,
    init_db,
    session_scope,
)

logger = logging.getLogger("tenderbot.main")

# One instance of each agent for the whole process.
scraper = ScraperAgent()
analyzer = AnalyzerAgent()
comms = CommunicationAgent()
tax_agent = TaxAgent()
submitter = AssistedSubmitter()


# ===========================================================================
# Request / response schemas
# ===========================================================================
class DispatchStatus(BaseModel):
    sent: bool
    message_sid: Optional[str] = None
    error: Optional[str] = None


class AnalyzeTenderRequest(BaseModel):
    tender_summary: TenderSummary
    vendor_documents: VendorProfile
    send_whatsapp: bool = True


class AnalyzeTenderResponse(BaseModel):
    tender_id: str
    ready_for_submission: bool
    report: GapReport
    whatsapp: DispatchStatus
    next_action: str


class SubmitApprovalRequest(BaseModel):
    tender_id: str = Field(min_length=1)
    bid_amount: float = Field(gt=0, description="Bid amount in INR")
    vendor_whatsapp_number: str
    vendor_voice_number: Optional[str] = None
    language: Optional[Literal["mr", "en", "both"]] = None


class SubmitApprovalResponse(BaseModel):
    approval_id: int
    status: str
    expires_at: datetime
    voice_call: DispatchStatus
    whatsapp: DispatchStatus


class ScanTendersRequest(BaseModel):
    vendor: VendorProfile
    min_score: Optional[int] = Field(default=None, ge=0, le=100)
    notify: bool = False
    enable_monitoring: bool = False


class ScanTendersResponse(BaseModel):
    total_matches: int
    new_matches: int
    tenders: list[TenderSummary]
    portal_status: dict[str, str]
    whatsapp: Optional[DispatchStatus] = None


# ===========================================================================
# Persistence helpers
# ===========================================================================
def upsert_vendor(db: Session, profile: VendorProfile, enable_monitoring: Optional[bool] = None) -> Vendor:
    vendor = db.scalar(select(Vendor).where(Vendor.whatsapp_number == profile.whatsapp_number))
    payload = profile.model_dump(mode="json")
    if vendor is None:
        vendor = Vendor(whatsapp_number=profile.whatsapp_number, name=profile.vendor_name)
        db.add(vendor)
    vendor.name = profile.vendor_name
    vendor.voice_number = profile.voice_number
    vendor.language = profile.preferred_language
    vendor.profile = payload
    if enable_monitoring is not None:
        vendor.monitoring_enabled = enable_monitoring
    db.commit()
    db.refresh(vendor)
    return vendor


def upsert_tender(db: Session, tender: TenderSummary) -> Tender:
    row = db.scalar(select(Tender).where(Tender.tender_id == tender.tender_id))
    data = tender.model_dump(mode="json")
    if row is None:
        row = Tender(tender_id=tender.tender_id)
        db.add(row)
    row.portal = tender.portal
    row.title = tender.title
    row.data = data
    db.commit()
    db.refresh(row)
    return row


def persist_scanned_tenders(db: Session, tenders: list[TenderSummary]) -> list[TenderSummary]:
    """Store scraped tenders; return only the ones never seen before."""
    existing = set(db.scalars(select(Tender.tender_id).where(Tender.tender_id.in_([t.tender_id for t in tenders]))).all()) if tenders else set()
    new = [t for t in tenders if t.tender_id not in existing]
    for t in tenders:
        upsert_tender(db, t)
    return new


def upsert_analysis(db: Session, tender: Tender, vendor: Vendor, report: GapReport) -> TenderAnalysis:
    row = db.scalar(
        select(TenderAnalysis).where(TenderAnalysis.tender_pk == tender.id, TenderAnalysis.vendor_id == vendor.id)
    )
    if row is None:
        row = TenderAnalysis(tender_pk=tender.id, vendor_id=vendor.id)
        db.add(row)
    row.ready_for_submission = report.ready_for_submission
    row.report = report.model_dump(mode="json")
    db.commit()
    db.refresh(row)
    return row


def vendor_language(vendor: Vendor) -> str:
    return vendor.language if vendor.language in ("mr", "en", "both") else "mr"


def _tender_from_row(row: Tender) -> TenderSummary:
    return TenderSummary.model_validate(row.data)


def _vendor_from_row(row: Vendor) -> VendorProfile:
    return VendorProfile.model_validate(row.profile)


async def safe_whatsapp(to: str, body: str) -> DispatchStatus:
    """Send a WhatsApp message; never raise (notification failures must not fail the API call)."""
    try:
        sids = await comms.send_whatsapp(to, body)
        return DispatchStatus(sent=True, message_sid=sids[0] if sids else None)
    except CommunicationError as exc:
        logger.warning("WhatsApp dispatch failed: %s", exc)
        return DispatchStatus(sent=False, error=str(exc))


# ===========================================================================
# Twilio webhook security
# ===========================================================================
def verify_twilio_request(request: Request, form_data: dict[str, str]) -> None:
    """Reject webhook calls that do not carry a valid X-Twilio-Signature."""
    if not settings.twilio_validate_signature:
        return
    url = f"{settings.base_url}{request.url.path}"
    if request.url.query:
        url += f"?{request.url.query}"
    signature = request.headers.get("X-Twilio-Signature", "")
    if not comms.verify_signature(url, form_data, signature):
        logger.warning("Invalid Twilio signature for %s", url)
        raise HTTPException(status_code=403, detail="Invalid Twilio signature")


# ===========================================================================
# Approval decision engine (shared by WhatsApp and Voice)
# ===========================================================================
async def apply_decision(
    db: Session,
    approval: ApprovalRequest,
    decision: Decision,
    channel: Literal["whatsapp", "voice"],
    raw_text: str,
    background: BackgroundTasks,
) -> tuple[str, str]:
    """
    Apply a YES/NO to an approval. Returns (english_reply, marathi_reply).
    Safety properties: only PENDING approvals can change, expired ones never execute,
    UNKNOWN answers change nothing.
    """
    tender_id = approval.tender.tender_id
    amount = format_inr(approval.bid_amount)

    if approval.status != ApprovalStatus.PENDING.value:
        return (
            f"This request for tender {tender_id} is already {approval.status.lower().replace('_', ' ')}. No further action taken.",
            f"निविदा {tender_id} ची ही विनंती आधीच '{approval.status}' स्थितीत आहे. पुढील कोणतीही कृती केली नाही.",
        )

    if approval.expires_at < now_ist():
        approval.status = ApprovalStatus.EXPIRED.value
        approval.resolved_at = now_ist()
        db.commit()
        return (
            f"This approval request for tender {tender_id} has expired, so nothing was submitted. Please request a new approval.",
            f"निविदा {tender_id} साठीची मंजुरीची विनंती कालबाह्य झाली आहे, त्यामुळे काहीही सादर केले नाही. कृपया नवीन विनंती करा.",
        )

    if decision == Decision.UNKNOWN:
        return (
            f"Sorry, I did not understand. Reply YES to submit the bid of {amount} for tender {tender_id}, or NO to cancel.",
            f"क्षमस्व, मला समजले नाही. निविदा {tender_id} साठी {amount} ची बोली सादर करण्यासाठी 'होय' (YES) किंवा रद्द करण्यासाठी 'नाही' (NO) लिहा.",
        )

    approval.resolved_via = channel
    approval.decision_text = raw_text[:500]
    approval.resolved_at = now_ist()

    if decision == Decision.NO:
        approval.status = ApprovalStatus.REJECTED.value
        db.commit()
        return (
            f"Understood. The bid for tender {tender_id} will NOT be submitted.",
            f"समजले. निविदा {tender_id} ची बोली सादर केली जाणार नाही.",
        )

    approval.status = ApprovalStatus.APPROVED.value
    db.commit()
    background.add_task(run_submission_flow, approval.id)  # heavy work happens after the reply is sent
    return (
        f"Thank you. Approved: bid of {amount} for tender {tender_id}. I am preparing the submission now and will message you shortly.",
        f"धन्यवाद. मंजूर: निविदा {tender_id} साठी {amount} ची बोली. मी सादरीकरणाची तयारी करत आहे आणि लवकरच संदेश पाठवतो.",
    )


async def run_submission_flow(approval_id: int) -> None:
    """Background job started by a YES: build the bid package and notify the vendor."""
    with session_scope() as db:
        approval = db.get(ApprovalRequest, approval_id)
        if approval is None or approval.status != ApprovalStatus.APPROVED.value:
            return
        tender = _tender_from_row(approval.tender)
        vendor_row = approval.vendor
        vendor = _vendor_from_row(vendor_row)
        language = vendor_language(vendor_row)
        try:
            result = await submitter.submit(tender, vendor, approval.bid_amount)
            approval.status = result.status
            approval.submission = result.model_dump(mode="json")
            message = bilingual(language, result.message_en, result.message_mr, sep="\n\n──────────\n\n")
        except Exception as exc:
            logger.exception("Submission flow failed for approval %s", approval_id)
            approval.status = ApprovalStatus.FAILED.value
            approval.submission = {"error": f"{type(exc).__name__}: {exc}"}
            message = bilingual(
                language,
                f"⚠️ I could not prepare the submission for tender {tender.tender_id}. Please submit manually on the portal.",
                f"⚠️ निविदा {tender.tender_id} साठी सादरीकरणाची तयारी करता आली नाही. कृपया पोर्टलवर स्वतः सादर करा.",
            )
        db.commit()
        number = vendor_row.whatsapp_number

    status = await safe_whatsapp(number, message)
    if not status.sent:
        logger.error("Could not notify vendor about submission result: %s", status.error)


# ===========================================================================
# Background tender monitor (optional)
# ===========================================================================
async def run_monitor_cycle() -> None:
    with session_scope() as db:
        vendors = db.scalars(select(Vendor).where(Vendor.monitoring_enabled.is_(True))).all()
        profiles = [(v.whatsapp_number, vendor_language(v), _vendor_from_row(v)) for v in vendors]

    for number, language, profile in profiles:
        try:
            scan = await scraper.scan(profile)
            with session_scope() as db:
                new = persist_scanned_tenders(db, scan.tenders)
            if new:
                body = comms.build_new_tenders_alert(profile.vendor_name, new, language)
                await safe_whatsapp(number, body)
        except Exception:
            logger.exception("Monitor cycle failed for vendor %s", number)


async def tender_monitor_loop() -> None:
    while True:
        try:
            await run_monitor_cycle()
        except Exception:
            logger.exception("Tender monitor crashed; will retry next interval")
        await asyncio.sleep(max(1, settings.monitor_interval_minutes) * 60)


# ===========================================================================
# App
# ===========================================================================
@asynccontextmanager
async def lifespan(_: FastAPI):
    configure_logging()
    init_db()
    monitor_task = asyncio.create_task(tender_monitor_loop()) if settings.enable_tender_monitor else None
    logger.info("%s %s started (monitor=%s)", settings.app_name, settings.app_version, bool(monitor_task))
    yield
    if monitor_task:
        monitor_task.cancel()


app = FastAPI(
    title=settings.app_name,
    version=settings.app_version,
    description="Agentic Tender Hunter & Tax Assistant for Indian contractors and MSMEs.",
    lifespan=lifespan,
)


# ---------------------------------------------------------------------------
# 1. Health check
# ---------------------------------------------------------------------------
@app.get("/")
async def health() -> dict:
    return {
        "status": "ok",
        "service": settings.app_name,
        "version": settings.app_version,
        "environment": settings.environment,
        "time_ist": now_ist().isoformat(timespec="seconds"),
        "integrations": {
            "openai_configured": settings.llm_configured,
            "twilio_configured": settings.twilio_configured,
            "scraper_mode": settings.scraper_mode,
            "tender_monitor": settings.enable_tender_monitor,
        },
    }


# ---------------------------------------------------------------------------
# Extra: tender discovery
# ---------------------------------------------------------------------------
@app.post("/scan-tenders", response_model=ScanTendersResponse)
async def scan_tenders(req: ScanTendersRequest, db: Session = Depends(get_db)) -> ScanTendersResponse:
    """Scrape Mahatenders / GeM / CPPP, rank the results for this vendor, optionally WhatsApp the best."""
    vendor = upsert_vendor(db, req.vendor, enable_monitoring=req.enable_monitoring or None)
    scan = await scraper.scan(req.vendor, min_score=req.min_score)
    new = persist_scanned_tenders(db, scan.tenders)

    dispatch: Optional[DispatchStatus] = None
    if req.notify and new:
        body = comms.build_new_tenders_alert(req.vendor.vendor_name, new, vendor_language(vendor))
        dispatch = await safe_whatsapp(vendor.whatsapp_number, body)

    return ScanTendersResponse(
        total_matches=len(scan.tenders), new_matches=len(new), tenders=scan.tenders,
        portal_status=scan.portal_status, whatsapp=dispatch,
    )


# ---------------------------------------------------------------------------
# 2. Analyze tender -> gap checklist -> WhatsApp alert
# ---------------------------------------------------------------------------
@app.post("/analyze-tender", response_model=AnalyzeTenderResponse)
async def analyze_tender(req: AnalyzeTenderRequest, db: Session = Depends(get_db)) -> AnalyzeTenderResponse:
    try:
        report = await analyzer.analyze(req.tender_summary, req.vendor_documents)
    except AnalysisInputError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

    vendor = upsert_vendor(db, req.vendor_documents)
    tender = upsert_tender(db, req.tender_summary)
    upsert_analysis(db, tender, vendor, report)

    if req.send_whatsapp:
        body = comms.build_gap_alert(vendor.name, req.tender_summary, report, vendor_language(vendor))
        dispatch = await safe_whatsapp(vendor.whatsapp_number, body)
    else:
        dispatch = DispatchStatus(sent=False, error="send_whatsapp=false")

    next_action = (
        "All documents are complete. Call POST /request-submit-approval to ask the vendor for approval."
        if report.ready_for_submission
        else "Collect the missing items listed in the report, then call /analyze-tender again."
    )
    return AnalyzeTenderResponse(
        tender_id=req.tender_summary.tender_id,
        ready_for_submission=report.ready_for_submission,
        report=report,
        whatsapp=dispatch,
        next_action=next_action,
    )


# ---------------------------------------------------------------------------
# 3. Request submit approval -> Twilio voice call + WhatsApp prompt
# ---------------------------------------------------------------------------
@app.post("/request-submit-approval", response_model=SubmitApprovalResponse)
async def request_submit_approval(req: SubmitApprovalRequest, db: Session = Depends(get_db)) -> SubmitApprovalResponse:
    try:
        whatsapp_number = normalize_phone(req.vendor_whatsapp_number)
        voice_override = normalize_phone(req.vendor_voice_number) if req.vendor_voice_number else None
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

    vendor = db.scalar(select(Vendor).where(Vendor.whatsapp_number == whatsapp_number))
    if vendor is None:
        raise HTTPException(404, "Vendor not found. Run POST /analyze-tender for this vendor first.")
    tender = db.scalar(select(Tender).where(Tender.tender_id == req.tender_id))
    if tender is None:
        raise HTTPException(404, f"Tender {req.tender_id} not found. Run POST /analyze-tender first.")

    # Gate 1: the latest analysis for this vendor + tender must say "ready".
    analysis = db.scalar(
        select(TenderAnalysis).where(TenderAnalysis.tender_pk == tender.id, TenderAnalysis.vendor_id == vendor.id)
    )
    if analysis is None:
        raise HTTPException(409, "No document analysis exists for this vendor and tender. Run /analyze-tender first.")
    if not analysis.ready_for_submission:
        raise HTTPException(409, {
            "message": "Documents are not complete; approval cannot be requested.",
            "checklist_en": analysis.report.get("checklist_en"),
            "checklist_mr": analysis.report.get("checklist_mr"),
        })

    # Gate 2: the bid deadline must still be in the future.
    deadline = to_naive_ist(_tender_from_row(tender).deadline)
    if deadline and deadline < now_ist():
        raise HTTPException(409, f"The bid deadline ({deadline:%d-%b-%Y %H:%M}) has passed.")

    # Gate 3: only one open request per vendor + tender.
    open_request = db.scalar(
        select(ApprovalRequest).where(
            ApprovalRequest.tender_pk == tender.id,
            ApprovalRequest.vendor_id == vendor.id,
            ApprovalRequest.status == ApprovalStatus.PENDING.value,
            ApprovalRequest.expires_at > now_ist(),
        )
    )
    if open_request is not None:
        raise HTTPException(409, f"An approval request (id {open_request.id}) is already pending for this tender.")

    language = req.language or vendor_language(vendor)
    approval = ApprovalRequest(
        tender_pk=tender.id,
        vendor_id=vendor.id,
        bid_amount=req.bid_amount,
        status=ApprovalStatus.PENDING.value,
        expires_at=now_ist() + timedelta(minutes=settings.approval_ttl_minutes),
    )
    db.add(approval)
    db.commit()  # persisted BEFORE contacting the vendor so a fast reply always finds it
    db.refresh(approval)

    voice_number = voice_override or vendor.voice_number or vendor.whatsapp_number
    call_result, wa_result = await asyncio.gather(
        comms.place_approval_call(voice_number, approval.id, vendor.name, tender.tender_id, req.bid_amount, language),
        comms.send_approval_prompt(vendor.whatsapp_number, vendor.name, tender.tender_id, req.bid_amount, language),
        return_exceptions=True,
    )

    voice = (
        DispatchStatus(sent=False, error=str(call_result))
        if isinstance(call_result, BaseException) else DispatchStatus(sent=True, message_sid=call_result)
    )
    whatsapp = (
        DispatchStatus(sent=False, error=str(wa_result))
        if isinstance(wa_result, BaseException) else DispatchStatus(sent=True, message_sid=wa_result)
    )
    if voice.sent:
        approval.call_sid = voice.message_sid
    if whatsapp.sent:
        approval.whatsapp_sid = whatsapp.message_sid

    if not voice.sent and not whatsapp.sent:
        approval.status = ApprovalStatus.FAILED.value
        db.commit()
        raise HTTPException(502, {
            "message": "Could not reach the vendor on WhatsApp or by voice call.",
            "voice_error": voice.error,
            "whatsapp_error": whatsapp.error,
        })
    db.commit()

    return SubmitApprovalResponse(
        approval_id=approval.id, status=approval.status, expires_at=approval.expires_at,
        voice_call=voice, whatsapp=whatsapp,
    )


# ---------------------------------------------------------------------------
# 4a. WhatsApp webhook (YES / NO)
# ---------------------------------------------------------------------------
@app.post("/whatsapp-webhook")
async def whatsapp_webhook(request: Request, background: BackgroundTasks, db: Session = Depends(get_db)) -> Response:
    form = {k: str(v) for k, v in (await request.form()).items()}
    verify_twilio_request(request, form)

    # Quick-reply buttons arrive in ButtonPayload / ButtonText; typed replies arrive in Body.
    raw_text = form.get("ButtonPayload") or form.get("ButtonText") or form.get("Body") or ""
    xml = "application/xml"

    try:
        sender = normalize_phone(form.get("From", ""))
    except ValueError:
        return Response(comms.whatsapp_reply_twiml("Unrecognised sender."), media_type=xml)

    vendor = db.scalar(select(Vendor).where(Vendor.whatsapp_number == sender))
    approval = None
    if vendor is not None:
        approval = db.scalar(
            select(ApprovalRequest)
            .where(ApprovalRequest.vendor_id == vendor.id)
            .order_by(ApprovalRequest.created_at.desc())
            .limit(1)
        )
    if approval is None:
        return Response(
            comms.whatsapp_reply_twiml(
                "There is no approval request for this number.\nया क्रमांकासाठी कोणतीही मंजुरीची विनंती नाही."
            ),
            media_type=xml,
        )

    decision = parse_decision(raw_text)
    en, mr = await apply_decision(db, approval, decision, "whatsapp", raw_text, background)
    reply = bilingual(vendor_language(vendor), en, mr)
    return Response(comms.whatsapp_reply_twiml(reply), media_type=xml)


# ---------------------------------------------------------------------------
# 4b. Voice callback (keypad / speech from the <Gather>)
# ---------------------------------------------------------------------------
@app.post("/voice-response")
async def voice_response(
    request: Request,
    background: BackgroundTasks,
    approval_id: int,
    attempt: int = 1,
    db: Session = Depends(get_db),
) -> Response:
    form = {k: str(v) for k, v in (await request.form()).items()}
    verify_twilio_request(request, form)
    xml = "application/xml"

    approval = db.get(ApprovalRequest, approval_id)
    if approval is None:
        return Response(comms.voice_message_twiml("both", "Request not found. Goodbye.", "विनंती सापडली नाही. धन्यवाद."), media_type=xml)

    vendor = approval.vendor
    language = vendor_language(vendor)
    raw = form.get("Digits") or form.get("SpeechResult") or ""
    decision = parse_decision(raw)

    # Unclear answer: ask again (max 3 attempts), the WhatsApp prompt stays valid either way.
    if decision == Decision.UNKNOWN and approval.status == ApprovalStatus.PENDING.value:
        if attempt < 3:
            twiml = comms.approval_twiml(
                approval.id, vendor.name, approval.tender.tender_id, approval.bid_amount, language, attempt=attempt + 1
            )
            return Response(twiml, media_type=xml)
        return Response(
            comms.voice_message_twiml(
                language,
                "I could not understand your answer. Please reply YES or NO on WhatsApp. Goodbye.",
                "आपले उत्तर समजले नाही. कृपया WhatsApp वर होय किंवा नाही असे उत्तर द्या. धन्यवाद.",
            ),
            media_type=xml,
        )

    en, mr = await apply_decision(db, approval, decision, "voice", raw, background)
    return Response(comms.voice_message_twiml(language, en, mr), media_type=xml)


# ---------------------------------------------------------------------------
# 5. GST & tax advice
# ---------------------------------------------------------------------------
@app.post("/get-tax-advice", response_model=TaxAdviceResponse)
async def get_tax_advice(req: TaxAdviceRequest, db: Session = Depends(get_db)) -> TaxAdviceResponse:
    result = await tax_agent.advise(req)
    db.add(
        TaxRecord(
            tender_id=req.tender_id,
            contract_amount=req.contract_amount,
            request=req.model_dump(mode="json"),
            result=result.model_dump(mode="json"),
        )
    )
    db.commit()
    return result


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=settings.environment == "development")
