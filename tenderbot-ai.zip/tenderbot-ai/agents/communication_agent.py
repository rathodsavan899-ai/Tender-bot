"""
agents/communication_agent.py - WhatsApp + automated voice calls through Twilio.

Execution flow
--------------
Outbound
  send_whatsapp()          -> plain WhatsApp text (auto-split under the 1600 char limit)
  send_approval_prompt()   -> "Should I submit the bid?" with YES / NO quick-reply buttons
                              (Content API template) or a plain text fallback
  place_approval_call()    -> Twilio Voice call whose TwiML <Gather> accepts keypad (1/2)
                              or speech (yes/no/होय/नाही) and posts to /voice-response
Inbound
  parse_decision()         -> YES / NO / UNKNOWN from WhatsApp text, button payload or speech
  verify_signature()       -> validates X-Twilio-Signature on webhooks
Builders
  build_gap_alert(), build_new_tenders_alert(), TwiML helpers - all bilingual (Marathi/English).

Twilio's SDK is synchronous, so every API call runs in a worker thread.
"""
from __future__ import annotations

import asyncio
import json
import logging
import string
from enum import Enum
from typing import Optional, Sequence

from twilio.base.exceptions import TwilioRestException
from twilio.request_validator import RequestValidator
from twilio.rest import Client
from twilio.twiml.messaging_response import MessagingResponse
from twilio.twiml.voice_response import Gather, VoiceResponse

from agents.analyzer_agent import GapReport, TenderSummary
from config import format_inr, normalize_phone, settings, speech_amount

logger = logging.getLogger(__name__)


class CommunicationError(RuntimeError):
    """Twilio is not configured or the API rejected the request."""


class Decision(str, Enum):
    YES = "YES"
    NO = "NO"
    UNKNOWN = "UNKNOWN"


def bilingual(language: str, en: str, mr: str, sep: str = "\n\n") -> str:
    """Pick Marathi / English / both (Marathi first) depending on the vendor's preference."""
    if language == "en":
        return en
    if language == "mr":
        return mr
    return f"{mr}{sep}{en}"


# ---------------------------------------------------------------------------
# Decision parsing
# ---------------------------------------------------------------------------
_YES_TOKENS = {
    "yes", "y", "yep", "yeah", "ok", "okay", "approve", "approved", "confirm", "confirmed", "submit", "go",
    "1", "haan", "ha", "han", "hoy", "hoi", "होय", "हो", "हां", "हाँ", "हा", "ठीक", "ठिक", "मान्य", "सबमिट", "करा",
}
_NO_TOKENS = {
    "no", "n", "nope", "nah", "reject", "cancel", "stop", "dont", "don't", "2", "nahi", "nako", "naka",
    "नाही", "नाहि", "नही", "नको", "नका", "रद्द",
}
_STRIP = string.punctuation + "।॥…“”‘’"


def parse_decision(text: str) -> Decision:
    """
    Conservative YES/NO parser. Any NO token wins (never submit on ambiguity), and long
    free-form messages are UNKNOWN so a casual reply cannot trigger a bid submission.
    """
    if not text:
        return Decision.UNKNOWN
    if any(e in text for e in ("👎", "❌")):
        return Decision.NO
    tokens = [t.strip(_STRIP).lower() for t in text.split()]
    tokens = [t for t in tokens if t]
    if not tokens or len(tokens) > 6:
        return Decision.UNKNOWN
    if any(t in _NO_TOKENS for t in tokens):
        return Decision.NO
    if any(t in _YES_TOKENS for t in tokens) or any(e in text for e in ("👍", "✅")):
        return Decision.YES
    return Decision.UNKNOWN


# ---------------------------------------------------------------------------
# Agent
# ---------------------------------------------------------------------------
class CommunicationAgent:
    WHATSAPP_CHUNK = 1500

    def __init__(self) -> None:
        self._client: Optional[Client] = None

    # ---- plumbing ---------------------------------------------------------
    def _get_client(self) -> Client:
        if not settings.twilio_configured:
            raise CommunicationError("Twilio credentials are not configured (TWILIO_ACCOUNT_SID / TWILIO_AUTH_TOKEN)")
        if self._client is None:
            self._client = Client(settings.twilio_account_sid, settings.twilio_auth_token)
        return self._client

    @staticmethod
    def _wa(number: str) -> str:
        return f"whatsapp:{normalize_phone(number)}"

    def _wa_from(self) -> str:
        if not settings.twilio_whatsapp_from:
            raise CommunicationError("TWILIO_WHATSAPP_FROM is not configured")
        return self._wa(settings.twilio_whatsapp_from)

    @staticmethod
    def _chunks(text: str, size: int) -> list[str]:
        """Split on line boundaries so no WhatsApp message exceeds Twilio's body limit."""
        parts: list[str] = []
        current = ""
        for line in text.split("\n"):
            while len(line) > size:  # pathological single line
                if current:
                    parts.append(current)
                    current = ""
                parts.append(line[:size])
                line = line[size:]
            if len(current) + len(line) + 1 > size:
                parts.append(current)
                current = line
            else:
                current = f"{current}\n{line}" if current else line
        if current:
            parts.append(current)
        return parts or [""]

    # ---- WhatsApp ---------------------------------------------------------
    async def send_whatsapp(self, to: str, body: str) -> list[str]:
        """Send a WhatsApp message; returns the Twilio message SIDs."""
        client = self._get_client()
        sender, recipient = self._wa_from(), self._wa(to)

        def _send() -> list[str]:
            sids = []
            for chunk in self._chunks(body, self.WHATSAPP_CHUNK):
                sids.append(client.messages.create(from_=sender, to=recipient, body=chunk).sid)
            return sids

        try:
            return await asyncio.to_thread(_send)
        except TwilioRestException as exc:
            raise CommunicationError(f"Twilio WhatsApp error {exc.code}: {exc.msg}") from exc

    @staticmethod
    def approval_text(language: str, tender_id: str, amount: float) -> str:
        en = (
            "✅ All documents are ready.\n"
            f"Should I submit the bid of {format_inr(amount)} for Tender ID {tender_id}?\n\n"
            "Reply YES to submit or NO to cancel."
        )
        mr = (
            "✅ सर्व कागदपत्रे तयार आहेत.\n"
            f"निविदा क्रमांक {tender_id} साठी {format_inr(amount)} ची बोली सादर करू का?\n\n"
            "सादर करण्यासाठी 'होय' (YES) किंवा रद्द करण्यासाठी 'नाही' (NO) असे उत्तर द्या."
        )
        return bilingual(language, en, mr)

    async def send_approval_prompt(
        self, to: str, vendor_name: str, tender_id: str, amount: float, language: str
    ) -> str:
        """
        Interactive confirmation. With TWILIO_APPROVAL_CONTENT_SID the message carries YES/NO
        quick-reply buttons (variables: 1=tender id, 2=amount, 3=vendor name). If the template
        is not configured or is rejected, falls back to a plain text prompt (works inside the
        24-hour WhatsApp session window).
        """
        client = self._get_client()
        sender, recipient = self._wa_from(), self._wa(to)
        content_sid = settings.twilio_approval_content_sid

        def _send() -> str:
            if content_sid:
                try:
                    return client.messages.create(
                        from_=sender,
                        to=recipient,
                        content_sid=content_sid,
                        content_variables=json.dumps(
                            {"1": tender_id, "2": format_inr(amount), "3": vendor_name}, ensure_ascii=False
                        ),
                    ).sid
                except TwilioRestException as exc:
                    logger.warning("Quick-reply template failed (%s); falling back to text", exc.msg)
            return client.messages.create(
                from_=sender, to=recipient, body=self.approval_text(language, tender_id, amount)
            ).sid

        try:
            return await asyncio.to_thread(_send)
        except TwilioRestException as exc:
            raise CommunicationError(f"Twilio WhatsApp error {exc.code}: {exc.msg}") from exc

    # ---- Voice ------------------------------------------------------------
    @staticmethod
    def _speakable_id(tender_id: str) -> str:
        return tender_id.replace("_", " ").replace("-", " ")

    @staticmethod
    def _voice_script(language: str, vendor_name: str, tender_id: str, amount: float) -> list[tuple[str, str, str]]:
        """Returns [(BCP-47 language, voice name, text)] in the order they are spoken."""
        spoken_id = CommunicationAgent._speakable_id(tender_id)
        amt = speech_amount(amount)
        mr = (
            f"नमस्कार {vendor_name}. मी टेंडरबॉट एआय बोलत आहे. सर्व कागदपत्रे तयार आहेत. "
            f"निविदा क्रमांक {spoken_id} साठी {amt} रुपयांची बोली सादर करू का? "
            "होय म्हणण्यासाठी एक दाबा किंवा होय म्हणा. नाही म्हणण्यासाठी दोन दाबा किंवा नाही म्हणा."
        )
        en = (
            f"Hello {vendor_name}. This is TenderBot AI. All documents are ready. "
            f"Should I submit the bid of {amt} rupees for Tender ID {spoken_id}? "
            "Press 1 or say yes to approve. Press 2 or say no to cancel."
        )
        mr_entry = ("mr-IN", settings.twilio_voice_marathi, mr)
        en_entry = ("en-IN", settings.twilio_voice_english, en)
        if language == "en":
            return [en_entry]
        if language == "mr":
            return [mr_entry]
        return [mr_entry, en_entry]

    def approval_twiml(
        self, approval_id: int, vendor_name: str, tender_id: str, amount: float, language: str, attempt: int = 1
    ) -> str:
        """TwiML for the approval call. <Gather> posts the answer to /voice-response."""
        script = self._voice_script(language, vendor_name, tender_id, amount)
        speech_language = "en-IN" if language == "en" else "mr-IN"
        vr = VoiceResponse()
        gather = Gather(
            input="dtmf speech",
            num_digits=1,
            action=f"{settings.base_url}/voice-response?approval_id={approval_id}&attempt={attempt}",
            method="POST",
            timeout=8,
            speech_timeout="auto",
            language=speech_language,
            hints="होय, नाही, yes, no",
        )
        for lang, voice, text in script:
            gather.say(text, voice=voice, language=lang)
        vr.append(gather)
        # Reached only when the vendor gave no input at all.
        vr.say(
            "We did not receive a response. We have also sent you a WhatsApp message. Goodbye.",
            voice=settings.twilio_voice_english, language="en-IN",
        )
        vr.hangup()
        return str(vr)

    def voice_message_twiml(self, language: str, en: str, mr: str) -> str:
        """Say a closing message in the vendor's language and hang up."""
        vr = VoiceResponse()
        if language in ("mr", "both"):
            vr.say(mr, voice=settings.twilio_voice_marathi, language="mr-IN")
        if language in ("en", "both"):
            vr.say(en, voice=settings.twilio_voice_english, language="en-IN")
        vr.hangup()
        return str(vr)

    async def place_approval_call(
        self, to: str, approval_id: int, vendor_name: str, tender_id: str, amount: float, language: str
    ) -> str:
        """Place the automated Marathi/English approval call; returns the call SID."""
        client = self._get_client()
        if not settings.twilio_voice_from:
            raise CommunicationError("TWILIO_VOICE_FROM is not configured")
        recipient = normalize_phone(to)
        twiml = self.approval_twiml(approval_id, vendor_name, tender_id, amount, language)

        def _call() -> str:
            return client.calls.create(
                to=recipient, from_=normalize_phone(settings.twilio_voice_from), twiml=twiml, timeout=30
            ).sid

        try:
            return await asyncio.to_thread(_call)
        except TwilioRestException as exc:
            raise CommunicationError(f"Twilio Voice error {exc.code}: {exc.msg}") from exc

    # ---- webhooks ---------------------------------------------------------
    @staticmethod
    def whatsapp_reply_twiml(text: str) -> str:
        resp = MessagingResponse()
        resp.message(text)
        return str(resp)

    @staticmethod
    def verify_signature(url: str, params: dict[str, str], signature: str) -> bool:
        if not settings.twilio_auth_token or not signature:
            return False
        return RequestValidator(settings.twilio_auth_token).validate(url, params, signature)

    # ---- message builders -------------------------------------------------
    @staticmethod
    def build_gap_alert(vendor_name: str, tender: TenderSummary, report: GapReport, language: str) -> str:
        link = f"\n{tender.url}" if tender.url else ""
        title = tender.title[:120] if tender.title else tender.tender_id
        if report.ready_for_submission:
            en = (
                f"Hello {vendor_name},\nTender {tender.tender_id} ({title})\n\n"
                f"{report.summary_en}\n\nYou will receive a confirmation request shortly.{link}"
            )
            mr = (
                f"नमस्कार {vendor_name},\nनिविदा {tender.tender_id} ({title})\n\n"
                f"{report.summary_mr}\n\nलवकरच आपल्याला मंजुरीची विनंती येईल.{link}"
            )
        else:
            en = (
                f"Hello {vendor_name},\nTender {tender.tender_id} ({title})\n\n"
                f"{report.summary_en}\n\nMissing / to fix:\n{report.checklist_en}{link}"
            )
            mr = (
                f"नमस्कार {vendor_name},\nनिविदा {tender.tender_id} ({title})\n\n"
                f"{report.summary_mr}\n\nअपूर्ण / दुरुस्त करायचे:\n{report.checklist_mr}{link}"
            )
        return bilingual(language, en, mr, sep="\n\n──────────\n\n")

    @staticmethod
    def build_new_tenders_alert(vendor_name: str, tenders: Sequence[TenderSummary], language: str) -> str:
        en_lines, mr_lines = [], []
        for t in tenders[:5]:
            value = f" | {format_inr(t.estimated_value)}" if t.estimated_value else ""
            due = f" | last date {t.deadline:%d-%b}" if t.deadline else ""
            due_mr = f" | अंतिम तारीख {t.deadline:%d-%m}" if t.deadline else ""
            en_lines.append(f"• {t.tender_id}: {t.title[:90]}{value}{due} (match {t.match_score}%)\n  {t.url or ''}".rstrip())
            mr_lines.append(f"• {t.tender_id}: {t.title[:90]}{value}{due_mr} (जुळणी {t.match_score}%)\n  {t.url or ''}".rstrip())
        en = f"Hello {vendor_name}, {len(tenders)} new matching tender(s):\n" + "\n".join(en_lines)
        mr = f"नमस्कार {vendor_name}, आपल्यासाठी {len(tenders)} नवीन निविदा आढळल्या:\n" + "\n".join(mr_lines)
        return bilingual(language, en, mr, sep="\n\n──────────\n\n")
