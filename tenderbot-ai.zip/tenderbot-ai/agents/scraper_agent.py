"""
agents/scraper_agent.py - Tender discovery, matching and bid-package preparation.

Execution flow of `ScraperAgent.scan(vendor)`
---------------------------------------------
1. Fetch the latest active tenders from every portal concurrently
   (Mahatenders and CPPP eProcurement are NIC GePNIC sites -> HTML tables;
   GeM is queried through its JSON search endpoint with a CSRF cookie).
   SCRAPER_MODE=mock returns built-in sample tenders for local demos.
2. Per-portal failures are isolated: one broken portal never fails the scan,
   its error is reported in `portal_status`.
3. Tenders are de-duplicated, scored against the vendor profile
   (keywords, state, turnover fit, deadline) and filtered by MATCH_SCORE_THRESHOLD.

IMPORTANT: portal HTML / APIs change without notice and some pages sit behind
CAPTCHAs. Check each portal's terms of use and robots policy before running this in
production, and keep request rates low. The parsers are defensive but should be
re-verified periodically (see README).

`AssistedSubmitter` at the bottom of the file implements the post-approval flow.
Portal submission needs the vendor's Class-3 DSC token and CAPTCHA solving, which
cannot (and should not) be automated blindly, so the default submitter prepares the
complete bid package and hands the final signed step to the vendor.
"""
from __future__ import annotations

import asyncio
import json
import logging
import re
from abc import ABC, abstractmethod
from datetime import datetime, timedelta
from typing import Any, Literal, Optional
from urllib.parse import urljoin

import httpx
from bs4 import BeautifulSoup
from pydantic import BaseModel, Field

from agents.analyzer_agent import TenderSummary, VendorProfile, canonicalize_doc_type
from config import format_inr, now_ist, settings, to_naive_ist

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Date parsing
# ---------------------------------------------------------------------------
_DATE_FORMATS = [
    "%d-%b-%Y %I:%M %p",
    "%d-%b-%Y %H:%M",
    "%d-%m-%Y %H:%M",
    "%d-%m-%Y %I:%M %p",
    "%d/%m/%Y %H:%M",
    "%d-%b-%Y",
    "%d-%m-%Y",
    "%Y-%m-%d %H:%M:%S",
    "%Y-%m-%dT%H:%M:%S",
]
_GEPNIC_DATE_RE = re.compile(r"\d{2}-[A-Za-z]{3}-\d{4}\s+\d{1,2}:\d{2}\s*[APap][Mm]")


def parse_portal_datetime(value: Any) -> Optional[datetime]:
    """Parse the many date formats used by Indian procurement portals (returns naive IST)."""
    if not value:
        return None
    text = str(value).strip()
    try:  # ISO 8601 with optional Z / offset (GeM)
        return to_naive_ist(datetime.fromisoformat(text.replace("Z", "+00:00")))
    except ValueError:
        pass
    for fmt in _DATE_FORMATS:
        try:
            return datetime.strptime(text, fmt)
        except ValueError:
            continue
    return None


def _first(value: Any) -> Any:
    """GeM search returns many fields as single-element lists."""
    if isinstance(value, list):
        return value[0] if value else None
    return value


# ---------------------------------------------------------------------------
# GePNIC HTML parsing (Mahatenders, CPPP eProcure)
# ---------------------------------------------------------------------------
def parse_gepnic_html(html: str, portal: str, page_url: str) -> tuple[list[TenderSummary], Optional[str]]:
    """
    Parse the 'Latest Active Tenders' table of a GePNIC portal.
    Returns (tenders, next_page_url). Columns are expected as:
    S.No | e-Published | Closing | Opening | Title and Ref.No./Tender ID | Organisation Chain
    """
    soup = BeautifulSoup(html, "html.parser")
    table = soup.find("table", id="table") or soup.find("table", class_=re.compile("list_table"))
    tenders: list[TenderSummary] = []
    if table is not None:
        for tr in table.find_all("tr"):
            cells = tr.find_all("td", recursive=False)
            if len(cells) < 5:
                continue
            texts = [c.get_text(" ", strip=True) for c in cells]
            dates = [m.group(0) for t in texts for m in [_GEPNIC_DATE_RE.search(t)] if m]
            link = tr.find("a", href=True)

            if len(cells) >= 6:
                title_cell, org_cell = texts[4], texts[5]
            else:
                title_cell, org_cell = max(texts, key=len), ""

            ids = re.findall(r"\[([^\[\]]+)\]", title_cell)
            tender_id = ids[-1].strip() if ids else None
            if not tender_id:
                continue
            title = re.sub(r"\[[^\[\]]+\]", "", title_cell).strip(" /-")
            tenders.append(
                TenderSummary(
                    tender_id=tender_id,
                    portal=portal,
                    title=title or tender_id,
                    department=org_cell or None,
                    published_date=parse_portal_datetime(dates[0]) if len(dates) > 0 else None,
                    deadline=parse_portal_datetime(dates[1]) if len(dates) > 1 else None,
                    url=urljoin(page_url, link["href"]) if link else None,
                    summary_text=f"{title}. Organisation: {org_cell}".strip(),
                )
            )
    nxt = soup.find("a", id="linkFwd", href=True)
    return tenders, (urljoin(page_url, nxt["href"]) if nxt else None)


# ---------------------------------------------------------------------------
# Matching
# ---------------------------------------------------------------------------
def score_tender(tender: TenderSummary, vendor: VendorProfile) -> tuple[int, list[str]]:
    """Heuristic 0-100 relevance score + human-readable reasons."""
    haystack = " ".join(
        filter(None, [tender.title, tender.department, tender.category, tender.location, tender.summary_text])
    ).lower()
    reasons: list[str] = []
    score = 0

    keywords = [k.strip().lower() for k in vendor.business_keywords if k.strip()]
    if keywords:
        hits = [k for k in keywords if k in haystack]
        if hits:
            score += min(60, int(60 * len(hits) / max(1, min(len(keywords), 3))))
            reasons.append("Matches your business keywords: " + ", ".join(hits))
        else:
            reasons.append("No keyword match with your business profile")
    else:
        score += 30  # no keywords configured: neutral baseline

    states = [s.strip().lower() for s in vendor.preferred_states if s.strip()]
    if states and any(s in haystack for s in states):
        score += 15
        reasons.append("In your preferred state")

    if tender.estimated_value and vendor.annual_turnover:
        # Common eligibility rule of thumb: average turnover >= 30% of estimated cost.
        if vendor.annual_turnover >= 0.3 * tender.estimated_value:
            score += 25
            reasons.append(f"Value {format_inr(tender.estimated_value)} fits your turnover")
        else:
            reasons.append("Estimated value is high for your turnover (30% rule of thumb)")
    elif tender.estimated_value is None:
        score += 10

    deadline = to_naive_ist(tender.deadline)
    if deadline and deadline < now_ist():
        return 0, ["Deadline already passed"]
    if deadline:
        days = (deadline - now_ist()).days
        if days >= 3:
            score += 5
        reasons.append(f"{days} day(s) left to bid")
    return min(100, score), reasons


# ---------------------------------------------------------------------------
# Mock data (SCRAPER_MODE=mock)
# ---------------------------------------------------------------------------
def _mock_tenders() -> list[TenderSummary]:
    now = now_ist()
    rows = [
        ("MOCK-2026-PUN-1001", "Providing security guard services at Government Hospital, Pune for 12 months",
         "Public Health Department, Maharashtra", "Pune, Maharashtra", 4_800_000, 10),
        ("MOCK-2026-NSK-1002", "Housekeeping and manpower outsourcing for Zilla Parishad Nashik",
         "Zilla Parishad Nashik", "Nashik, Maharashtra", 2_500_000, 14),
        ("MOCK-2026-KOP-1003", "Repair and maintenance of rural roads, Kolhapur division (works contract)",
         "PWD Kolhapur", "Kolhapur, Maharashtra", 12_500_000, 21),
        ("MOCK-2026-NGP-1004", "Supply of office stationery to District Collector Office Nagpur",
         "District Collector Office Nagpur", "Nagpur, Maharashtra", 600_000, 7),
    ]
    return [
        TenderSummary(
            tender_id=tid, portal="Mock Portal", title=title, department=dept, location=loc,
            estimated_value=value, emd_amount=round(value * 0.02),
            published_date=now - timedelta(days=2), deadline=now + timedelta(days=days, hours=3),
            url=f"https://example.invalid/tenders/{tid}",
            summary_text=(
                f"{title}. Bidders must upload GST registration, PAN, EPF and ESIC registration, "
                "CA-certified turnover certificate for the last 3 years, work experience certificates "
                "of similar work, Udyam registration and a non-blacklisting affidavit. EMD is payable."
            ),
        )
        for tid, title, dept, loc, value, days in rows
    ]


class ScanResult(BaseModel):
    tenders: list[TenderSummary] = Field(default_factory=list)
    portal_status: dict[str, str] = Field(default_factory=dict)


# ---------------------------------------------------------------------------
# Scraper agent
# ---------------------------------------------------------------------------
class ScraperAgent:
    """Monitors Mahatenders, GeM and CPPP eProcurement and ranks tenders for a vendor."""

    MAX_PAGES = 5

    def _client(self) -> httpx.AsyncClient:
        return httpx.AsyncClient(
            timeout=settings.scraper_timeout_seconds,
            follow_redirects=True,
            headers={"User-Agent": settings.scraper_user_agent, "Accept-Language": "en-IN,en;q=0.9"},
        )

    async def _fetch_gepnic(self, portal: str, url: str) -> list[TenderSummary]:
        collected: list[TenderSummary] = []
        async with self._client() as client:
            page_url: Optional[str] = url
            for _ in range(self.MAX_PAGES):
                if not page_url or len(collected) >= settings.scraper_max_results_per_portal:
                    break
                resp = await client.get(page_url)
                resp.raise_for_status()
                tenders, page_url = parse_gepnic_html(resp.text, portal, str(resp.url))
                collected.extend(tenders)
                if not tenders:
                    break
        if not collected:
            raise RuntimeError("no tender rows found (portal layout changed or CAPTCHA page)")
        return collected[: settings.scraper_max_results_per_portal]

    async def _fetch_gem(self, vendor: VendorProfile) -> list[TenderSummary]:
        base = settings.gem_base_url.rstrip("/")
        keywords = [k for k in vendor.business_keywords if k.strip()][:4] or [""]
        collected: dict[str, TenderSummary] = {}
        async with self._client() as client:
            await client.get(f"{base}/all-bids")  # sets the csrf cookie
            csrf = client.cookies.get("csrf_gem_cookie") or ""
            for kw in keywords:
                payload = {
                    "page": 1,
                    "param": {"searchBid": kw, "searchType": "fullText"},
                    "filter": {"bidStatusType": "ongoing_bids", "byType": "all", "highBidValue": "",
                               "sort": "Bid-End-Date-Latest"},
                }
                resp = await client.post(
                    f"{base}/all-bids-data",
                    data={"payload": json.dumps(payload), "csrf_bd_gem_nks": csrf},
                    headers={"X-Requested-With": "XMLHttpRequest", "Referer": f"{base}/all-bids"},
                )
                resp.raise_for_status()
                docs = (resp.json().get("response") or {}).get("response", {}).get("docs", [])
                for d in docs:
                    bid_no = _first(d.get("b_bid_number"))
                    if not bid_no or bid_no in collected:
                        continue
                    category = _first(d.get("b_category_name")) or _first(d.get("bd_category_name"))
                    dept = " / ".join(
                        str(x) for x in [_first(d.get("ba_official_details_minName")),
                                         _first(d.get("ba_official_details_deptName"))] if x
                    )
                    bid_id = _first(d.get("b_id"))
                    collected[bid_no] = TenderSummary(
                        tender_id=str(bid_no),
                        portal="GeM",
                        title=str(category or bid_no),
                        category=str(category) if category else None,
                        department=dept or None,
                        published_date=parse_portal_datetime(_first(d.get("final_start_date_sort"))),
                        deadline=parse_portal_datetime(_first(d.get("final_end_date_sort"))),
                        url=f"{base}/showbidDocument/{bid_id}" if bid_id else None,
                        summary_text=f"GeM bid {bid_no}: {category or ''}. {dept}".strip(),
                    )
                await asyncio.sleep(1.0)  # be polite to the portal
        if not collected:
            raise RuntimeError("GeM returned no bids")
        return list(collected.values())[: settings.scraper_max_results_per_portal]

    async def scan(self, vendor: VendorProfile, min_score: Optional[int] = None) -> ScanResult:
        """Fetch -> de-duplicate -> score -> filter -> sort (best match first)."""
        threshold = settings.match_score_threshold if min_score is None else min_score
        result = ScanResult()

        if settings.scraper_mode == "mock":
            raw = _mock_tenders()
            result.portal_status["Mock Portal"] = f"ok: {len(raw)}"
        else:
            jobs = {
                "Mahatenders": self._fetch_gepnic("Mahatenders", settings.mahatenders_url),
                "eProcurement (CPPP)": self._fetch_gepnic("eProcurement (CPPP)", settings.cppp_url),
                "GeM": self._fetch_gem(vendor),
            }
            outcomes = await asyncio.gather(*jobs.values(), return_exceptions=True)
            raw = []
            for name, outcome in zip(jobs.keys(), outcomes):
                if isinstance(outcome, Exception):
                    logger.warning("Portal %s failed: %s", name, outcome)
                    result.portal_status[name] = f"error: {type(outcome).__name__}: {outcome}"
                else:
                    raw.extend(outcome)
                    result.portal_status[name] = f"ok: {len(outcome)}"

        unique: dict[str, TenderSummary] = {}
        for t in raw:
            unique.setdefault(t.tender_id, t)
        for t in unique.values():
            t.match_score, t.match_reasons = score_tender(t, vendor)
        result.tenders = sorted(
            (t for t in unique.values() if (t.match_score or 0) >= threshold),
            key=lambda t: t.match_score or 0,
            reverse=True,
        )
        return result


# ---------------------------------------------------------------------------
# Post-approval submission flow
# ---------------------------------------------------------------------------
class SubmissionResult(BaseModel):
    status: Literal["SUBMISSION_READY", "SUBMITTED"]
    reference: Optional[str] = None
    portal_url: Optional[str] = None
    packet: dict[str, Any] = Field(default_factory=dict)
    message_en: str
    message_mr: str


class PortalSubmitter(ABC):
    """Plug-in point: implement `submit` with a Playwright/Selenium driver + DSC integration."""

    @abstractmethod
    async def submit(self, tender: TenderSummary, vendor: VendorProfile, bid_amount: float) -> SubmissionResult:
        ...


class AssistedSubmitter(PortalSubmitter):
    """
    Default submitter. After the vendor's YES it assembles the bid package and the exact
    steps for the final DSC-signed submission. It never claims a bid was filed on the portal.
    """

    async def submit(self, tender: TenderSummary, vendor: VendorProfile, bid_amount: float) -> SubmissionResult:
        documents = [
            {"type": canonicalize_doc_type(d.doc_type), "name": d.doc_type, "number": d.number,
             "valid_until": d.valid_until.isoformat() if d.valid_until else None}
            for d in vendor.documents
        ]
        steps = [
            "Log in to the portal with your registered user ID and plug in your Class-3 DSC token.",
            f"Open tender {tender.tender_id} and choose 'Online Bid Submission'.",
            f"Enter the quoted amount: {format_inr(bid_amount)}.",
            "Upload the documents listed in this packet in the order the portal asks.",
            "Pay the EMD / upload the bid security proof if the tender requires it.",
            "Sign with the DSC and submit before the deadline; download the acknowledgement.",
        ]
        packet = {
            "tender_id": tender.tender_id,
            "portal": tender.portal,
            "title": tender.title,
            "bid_amount": bid_amount,
            "emd_amount": tender.emd_amount,
            "deadline": tender.deadline.isoformat() if tender.deadline else None,
            "documents": documents,
            "steps": steps,
            "prepared_at": now_ist().isoformat(timespec="seconds"),
        }
        deadline_txt = f"{tender.deadline:%d-%b-%Y %H:%M}" if tender.deadline else "the deadline"
        link = tender.url or ""
        msg_en = (
            f"✅ Approval recorded for tender {tender.tender_id} at {format_inr(bid_amount)}.\n"
            f"Your bid package is ready. The final step needs your DSC token on the portal - "
            f"please complete it before {deadline_txt}.\n{link}".strip()
        )
        msg_mr = (
            f"✅ निविदा {tender.tender_id} साठी {format_inr(bid_amount)} च्या बोलीला मंजुरी नोंदवली आहे.\n"
            f"आपले बोली पॅकेज तयार आहे. अंतिम टप्प्यासाठी पोर्टलवर आपला DSC टोकन आवश्यक आहे - "
            f"कृपया {deadline_txt} पूर्वी तो पूर्ण करा.\n{link}".strip()
        )
        return SubmissionResult(
            status="SUBMISSION_READY",
            portal_url=tender.url,
            packet=packet,
            message_en=msg_en,
            message_mr=msg_mr,
        )
