"""
agents/tax_agent.py - Post-award GST & tax-saving assistant.

Design rule: ALL NUMBERS ARE COMPUTED DETERMINISTICALLY with Decimal. The LLM (GPT-4o via
LangChain) only phrases the explanation in English/Marathi and suggests extra qualitative
strategies from the computed facts; it never calculates amounts.

Execution flow of `TaxAgent.advise(request)`
--------------------------------------------
1. compute_contract   : taxable value, 18% GST, CGST+SGST vs IGST from place of supply, RCM flag.
2. assess_expense     : per expense line -> ITC ELIGIBLE / BLOCKED (Sec 17(5)) / NO_INVOICE /
                        UNREGISTERED_SUPPLIER / NO_GST, plus recoverable ITC if the gap is fixed.
3. liability + profit : output GST - eligible ITC, GST-TDS and income-tax TDS estimates, margin.
4. rule_strategies    : concrete, number-backed saving strategies (EN + MR).
5. invoice draft      : GST tax-invoice draft with amount in words.
6. CA filing pack     : GSTR-1 / GSTR-3B oriented summary plus ITC registers and collection list.
7. AI narrative       : optional LLM summary + extra strategies; graceful fallback to templates.

This is decision support, not a substitute for a Chartered Accountant. Rates, thresholds and
notifications change; the response carries a disclaimer and the CA pack is meant for review.
"""
from __future__ import annotations

import json
import logging
import re
import uuid
from datetime import date
from decimal import ROUND_HALF_UP, Decimal
from typing import Any, Literal, Optional

from langchain_core.prompts import ChatPromptTemplate
from pydantic import BaseModel, Field

from config import LLMUnavailableError, format_inr, get_llm, now_ist, settings

logger = logging.getLogger(__name__)

Language = Literal["mr", "en", "both"]

# ---------------------------------------------------------------------------
# Reference data
# ---------------------------------------------------------------------------
GSTIN_RE = re.compile(r"^\d{2}[A-Z]{5}\d{4}[A-Z][1-9A-Z]Z[0-9A-Z]$")

STATE_NAMES = {
    "01": "Jammu & Kashmir", "02": "Himachal Pradesh", "03": "Punjab", "04": "Chandigarh", "05": "Uttarakhand",
    "06": "Haryana", "07": "Delhi", "08": "Rajasthan", "09": "Uttar Pradesh", "10": "Bihar", "11": "Sikkim",
    "12": "Arunachal Pradesh", "13": "Nagaland", "14": "Manipur", "15": "Mizoram", "16": "Tripura",
    "17": "Meghalaya", "18": "Assam", "19": "West Bengal", "20": "Jharkhand", "21": "Odisha", "22": "Chhattisgarh",
    "23": "Madhya Pradesh", "24": "Gujarat", "26": "Dadra & Nagar Haveli and Daman & Diu", "27": "Maharashtra",
    "29": "Karnataka", "30": "Goa", "31": "Lakshadweep", "32": "Kerala", "33": "Tamil Nadu", "34": "Puducherry",
    "35": "Andaman & Nicobar Islands", "36": "Telangana", "37": "Andhra Pradesh", "38": "Ladakh", "97": "Other Territory",
}

CATEGORY_ALIASES = {
    "salary": "labour_wages", "salaries": "labour_wages", "wages": "labour_wages", "labour": "labour_wages",
    "labor": "labour_wages", "manpower": "labour_wages", "manpower_wages": "labour_wages",
    "epf": "statutory_contributions", "esic": "statutory_contributions", "pf": "statutory_contributions",
    "bonus": "statutory_contributions", "statutory": "statutory_contributions",
    "interest": "financial_charges", "bank_charges": "financial_charges", "loan_interest": "financial_charges",
    "car": "motor_vehicle_passenger", "vehicle": "motor_vehicle_passenger", "motor_vehicle": "motor_vehicle_passenger",
    "food": "food_beverage", "catering": "food_beverage", "meals": "food_beverage", "canteen": "food_beverage",
    "club": "club_membership", "gym": "club_membership",
    "personal": "personal_consumption",
    "construction": "construction_immovable", "building": "construction_immovable",
    "gifts": "gifts_free_samples", "gift": "gifts_free_samples",
    "material": "raw_material", "materials": "raw_material", "uniform": "uniforms", "tools": "equipment",
    "machinery": "capital_goods", "subcontract": "subcontract_services", "subcontractor": "subcontract_services",
    "freight": "transport", "rent": "rent_commercial", "legal": "professional_fees", "ca_fees": "professional_fees",
    "electricity": "utilities", "phone": "telecom", "repairs": "repairs_maintenance", "maintenance": "repairs_maintenance",
}
NO_GST_CATEGORIES = {"labour_wages", "statutory_contributions", "financial_charges"}
BLOCKED_REASONS: dict[str, tuple[str, str]] = {
    "motor_vehicle_passenger": (
        "Section 17(5): ITC on motor vehicles for carrying persons (up to 13 seats) is blocked except for specified businesses.",
        "कलम 17(5): १३ पर्यंत आसनांच्या प्रवासी वाहनांवरील ITC अवरोधित आहे (विशिष्ट व्यवसाय वगळता).",
    ),
    "food_beverage": (
        "Section 17(5): ITC on food, beverages and catering is blocked unless obligatory under law or used for the same type of outward supply.",
        "कलम 17(5): अन्न, पेये व केटरिंगवरील ITC अवरोधित आहे (कायद्याने बंधनकारक असल्यास किंवा त्याच प्रकारच्या पुरवठ्यासाठी वापरल्यास अपवाद).",
    ),
    "club_membership": (
        "Section 17(5): ITC on club / health & fitness memberships is blocked.",
        "कलम 17(5): क्लब / आरोग्य व फिटनेस सदस्यत्वावरील ITC अवरोधित आहे.",
    ),
    "health_beauty": (
        "Section 17(5): ITC on beauty treatment, health services and cosmetic surgery is blocked unless obligatory or part of a taxable supply.",
        "कलम 17(5): सौंदर्य उपचार, आरोग्य सेवा व कॉस्मेटिक शस्त्रक्रियेवरील ITC अवरोधित आहे.",
    ),
    "personal_consumption": (
        "ITC is not allowed on goods or services used for personal consumption.",
        "वैयक्तिक वापरासाठीच्या वस्तू/सेवांवर ITC मिळत नाही.",
    ),
    "construction_immovable": (
        "Section 17(5): ITC on works contract / construction of immovable property (other than plant & machinery) for own use is blocked.",
        "कलम 17(5): स्वतःच्या वापरासाठी स्थावर मालमत्तेच्या बांधकामावरील (प्लांट व मशिनरी वगळता) ITC अवरोधित आहे.",
    ),
    "gifts_free_samples": (
        "Section 17(5): ITC on goods given as gifts / free samples, or lost, stolen or destroyed, is blocked.",
        "कलम 17(5): भेट / मोफत नमुने किंवा हरवलेल्या, चोरीस गेलेल्या, नष्ट झालेल्या वस्तूंवरील ITC अवरोधित आहे.",
    ),
}
KNOWN_ELIGIBLE = {
    "raw_material", "consumables", "uniforms", "equipment", "capital_goods", "subcontract_services", "transport",
    "goods_vehicle", "rent_commercial", "professional_fees", "software", "utilities", "telecom", "insurance",
    "repairs_maintenance", "advertising",
}

# ---------------------------------------------------------------------------
# Money helpers
# ---------------------------------------------------------------------------
ZERO = Decimal("0")


def d(x: Any) -> Decimal:
    return Decimal(str(x))


def q(x: Decimal) -> Decimal:
    return x.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def fl(x: Decimal) -> float:
    return float(q(x))


_ONES = ["", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve",
         "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"]
_TENS = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"]


def _below_1000(n: int) -> str:
    parts = []
    if n >= 100:
        parts.append(f"{_ONES[n // 100]} Hundred")
        n %= 100
    if n >= 20:
        parts.append(_TENS[n // 10] + (f" {_ONES[n % 10]}" if n % 10 else ""))
    elif n > 0:
        parts.append(_ONES[n])
    return " ".join(parts)


def rupees_in_words(amount: Decimal) -> str:
    """Indian numbering (crore / lakh / thousand): 123456.50 -> 'Rupees One Lakh Twenty Three Thousand ... Only'."""
    amount = q(amount)
    rupees, paise = int(amount), int((amount - int(amount)) * 100)
    if rupees == 0 and paise == 0:
        return "Rupees Zero Only"
    chunks = []
    for label, size in (("Crore", 10_000_000), ("Lakh", 100_000), ("Thousand", 1_000)):
        if rupees >= size:
            chunks.append(f"{_below_1000(rupees // size)} {label}")
            rupees %= size
    if rupees:
        chunks.append(_below_1000(rupees))
    words = " ".join(chunks) if chunks else "Zero"
    text = f"Rupees {words}"
    if paise:
        text += f" and {_below_1000(paise)} Paise"
    return text + " Only"


def financial_year(day: date) -> str:
    start = day.year if day.month >= 4 else day.year - 1
    return f"{start}-{(start + 1) % 100:02d}"


# ---------------------------------------------------------------------------
# Schemas
# ---------------------------------------------------------------------------
class ExpenseItem(BaseModel):
    description: str = Field(min_length=1)
    category: str = Field(default="other", description="e.g. raw_material, uniforms, labour_wages, subcontract_services")
    amount: float = Field(ge=0, description="Taxable value in INR EXCLUDING GST")
    gst_rate: float = Field(default=18.0, ge=0, le=40)
    gst_paid: Optional[float] = Field(default=None, ge=0, description="Actual GST on the supplier invoice, if different from amount x rate")
    supplier_gstin: Optional[str] = None
    has_tax_invoice: bool = True


class TaxAdviceRequest(BaseModel):
    contract_amount: float = Field(gt=0, description="INR")
    gst_inclusive: bool = Field(default=False, description="True if contract_amount already includes GST")
    gst_rate: float = Field(default=settings.default_gst_rate, ge=0, le=40)
    expense_breakdown: list[ExpenseItem] = Field(default_factory=list)
    client_is_government: bool = True
    reverse_charge: bool = False
    vendor_entity_type: Literal["individual_huf", "company_firm"] = "company_firm"
    vendor_name: Optional[str] = None
    vendor_gstin: Optional[str] = None
    vendor_state_code: Optional[str] = Field(default=None, description="Two-digit GST state code, e.g. 27")
    client_name: Optional[str] = None
    client_gstin: Optional[str] = None
    place_of_supply_state_code: Optional[str] = None
    sac_code: str = Field(default="9985", description="9985 support services, 9954 construction, etc.")
    service_description: Optional[str] = None
    tender_id: Optional[str] = None
    invoice_number: Optional[str] = None
    invoice_date: Optional[date] = None
    language: Language = "both"
    use_ai: bool = True


class ContractTax(BaseModel):
    taxable_value: float
    gst_rate: float
    cgst: float
    sgst: float
    igst: float
    total_gst: float
    invoice_total: float
    supply_type: Literal["INTRA_STATE", "INTER_STATE"]
    reverse_charge: bool
    supplier_state: str
    place_of_supply: str


class ExpenseAssessment(BaseModel):
    description: str
    category: str
    taxable_value: float
    gst_amount: float
    itc_status: Literal["ELIGIBLE", "BLOCKED", "NO_INVOICE", "UNREGISTERED_SUPPLIER", "NO_GST"]
    itc_claimable: float
    itc_recoverable_if_fixed: float
    cost_borne: float = Field(description="Taxable value plus any GST you cannot claim back")
    reason_en: str
    reason_mr: str


class ItcSummary(BaseModel):
    eligible_itc: float
    blocked_itc: float
    lost_no_invoice: float
    lost_unregistered_supplier: float
    total_gst_on_expenses: float


class LiabilitySummary(BaseModel):
    output_gst: float
    itc_utilised: float
    net_gst_payable: float
    excess_itc_carry_forward: float
    gst_tds_expected: float
    net_gst_payable_after_tds_credit: float
    income_tax_tds_estimate: float
    notes_en: list[str] = Field(default_factory=list)
    notes_mr: list[str] = Field(default_factory=list)


class ProfitEstimate(BaseModel):
    revenue_taxable: float
    total_cost: float
    estimated_margin: float
    estimated_margin_percent: float


class TaxStrategy(BaseModel):
    title_en: str
    title_mr: str
    detail_en: str
    detail_mr: str
    estimated_itc_impact: Optional[float] = None
    source: Literal["rules", "ai"] = "rules"


class InvoiceDraft(BaseModel):
    status: Literal["DRAFT"] = "DRAFT"
    invoice_number: str
    invoice_date: str
    financial_year: str
    supplier: dict[str, Optional[str]]
    recipient: dict[str, Optional[str]]
    place_of_supply: str
    supply_type: str
    reverse_charge: bool
    line_items: list[dict[str, Any]]
    totals: dict[str, float]
    amount_in_words: str
    notes: list[str]


class TaxAdviceResponse(BaseModel):
    tender_id: Optional[str] = None
    contract: ContractTax
    itc: ItcSummary
    liability: LiabilitySummary
    profit: ProfitEstimate
    expense_assessment: list[ExpenseAssessment]
    strategies: list[TaxStrategy]
    invoice_draft: InvoiceDraft
    ca_filing_pack: dict[str, Any]
    summary_en: str
    summary_mr: str
    disclaimer_en: str
    disclaimer_mr: str
    ai_used: bool
    warnings: list[str] = Field(default_factory=list)


class AiStrategy(BaseModel):
    title_en: str
    title_mr: str = Field(description="Marathi, Devanagari")
    detail_en: str
    detail_mr: str = Field(description="Marathi, Devanagari")


class AiNarrative(BaseModel):
    summary_en: str
    summary_mr: str = Field(description="Marathi, Devanagari")
    extra_strategies: list[AiStrategy] = Field(default_factory=list)


NARRATIVE_SYSTEM = (
    "You are a GST and tax-saving assistant for small Indian contractors (labour, security and civil vendors). "
    "You receive a JSON of facts that were ALREADY CALCULATED. Write: (1) a short plain-language summary in "
    "English and in Marathi (Devanagari, simple spoken style; keep GST, ITC, CGST, SGST, IGST, TDS, RCM in Latin letters), "
    "and (2) at most 3 additional practical, lawful tax-saving or compliance strategies that are NOT already in "
    "existing_strategy_titles. Strict rules: do not recalculate; do not state any rupee figure that is not in the facts; "
    "do not suggest evasion, fake invoices or any unlawful step; mention that a CA should confirm."
)
NARRATIVE_HUMAN = "FACTS JSON:\n{facts}"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def valid_gstin(gstin: Optional[str]) -> bool:
    return bool(gstin) and bool(GSTIN_RE.match(gstin.strip().upper()))


def normalize_category(raw: str) -> str:
    key = re.sub(r"[\s\-/]+", "_", raw.strip().lower())
    return CATEGORY_ALIASES.get(key, key) or "other"


def state_of(gstin: Optional[str], explicit: Optional[str], fallback: str) -> str:
    if explicit and explicit.strip().isdigit():
        return explicit.strip().zfill(2)
    if valid_gstin(gstin):
        return gstin.strip().upper()[:2]  # type: ignore[union-attr]
    return fallback


def _state_label(code: str) -> str:
    return f"{code}-{STATE_NAMES.get(code, 'Unknown')}"


# ---------------------------------------------------------------------------
# Agent
# ---------------------------------------------------------------------------
class TaxAgent:
    # ---- 1. contract ------------------------------------------------------
    def compute_contract(self, req: TaxAdviceRequest) -> tuple[ContractTax, Decimal]:
        rate = d(req.gst_rate)
        amount = d(req.contract_amount)
        taxable = q(amount / (1 + rate / 100)) if req.gst_inclusive else q(amount)
        gst_total = q(taxable * rate / 100)

        supplier_state = state_of(req.vendor_gstin, req.vendor_state_code, "27")
        pos_state = state_of(req.client_gstin, req.place_of_supply_state_code, supplier_state)
        intra = supplier_state == pos_state
        if intra:
            cgst = q(gst_total / 2)
            sgst = gst_total - cgst
            igst = ZERO
        else:
            cgst = sgst = ZERO
            igst = gst_total

        invoice_total = taxable if req.reverse_charge else taxable + gst_total
        contract = ContractTax(
            taxable_value=fl(taxable), gst_rate=req.gst_rate, cgst=fl(cgst), sgst=fl(sgst), igst=fl(igst),
            total_gst=fl(gst_total), invoice_total=fl(invoice_total),
            supply_type="INTRA_STATE" if intra else "INTER_STATE", reverse_charge=req.reverse_charge,
            supplier_state=_state_label(supplier_state), place_of_supply=_state_label(pos_state),
        )
        return contract, taxable

    # ---- 2. expenses ------------------------------------------------------
    def assess_expense(self, item: ExpenseItem) -> tuple[ExpenseAssessment, Decimal, Decimal, Decimal]:
        """Returns (assessment, claimable, recoverable_no_invoice, recoverable_unregistered)."""
        cat = normalize_category(item.category)
        taxable = d(item.amount)
        unrecognised = cat not in KNOWN_ELIGIBLE and cat not in NO_GST_CATEGORIES and cat not in BLOCKED_REASONS
        caveat_en = " Category not recognised - confirm eligibility with your CA." if unrecognised else ""
        caveat_mr = " श्रेणी ओळखली गेली नाही - पात्रतेसाठी CA कडून खात्री करा." if unrecognised else ""

        claimable = recover_inv = recover_reg = ZERO

        if cat in NO_GST_CATEGORIES:
            gst = ZERO
            status = "NO_GST"
            en = "Wages, statutory contributions and financial charges carry no GST, so there is no ITC (cost only)."
            mr = "मजुरी, वैधानिक योगदान व वित्तीय शुल्कांवर GST लागत नाही, त्यामुळे ITC नाही (फक्त खर्च)."
        else:
            gst = q(d(item.gst_paid)) if item.gst_paid is not None else q(taxable * d(item.gst_rate) / 100)
            if cat in BLOCKED_REASONS:
                status = "BLOCKED"
                en, mr = BLOCKED_REASONS[cat]
            elif not item.has_tax_invoice:
                status = "NO_INVOICE"
                recover_inv = gst
                en = "No valid tax invoice: ITC cannot be claimed until you obtain one (Section 16(2))." + caveat_en
                mr = "वैध कर बीजक (tax invoice) नाही: ते मिळेपर्यंत ITC घेता येणार नाही (कलम 16(2))." + caveat_mr
            elif not valid_gstin(item.supplier_gstin):
                status = "UNREGISTERED_SUPPLIER"
                recover_reg = gst
                en = "Supplier GSTIN is missing or invalid: no ITC on purchases from unregistered suppliers." + caveat_en
                mr = "पुरवठादाराचा GSTIN नाही किंवा चुकीचा आहे: नोंदणी नसलेल्या पुरवठादाराकडून केलेल्या खरेदीवर ITC मिळत नाही." + caveat_mr
            else:
                status = "ELIGIBLE"
                claimable = gst
                en = "Eligible, provided the invoice appears in your GSTR-2B and the supplier is paid within 180 days." + caveat_en
                mr = "पात्र - बीजक GSTR-2B मध्ये दिसत असेल आणि पुरवठादाराला 180 दिवसांत payment केले असेल तर." + caveat_mr

        cost_borne = taxable + (gst - claimable)
        assessment = ExpenseAssessment(
            description=item.description, category=cat, taxable_value=fl(taxable), gst_amount=fl(gst),
            itc_status=status, itc_claimable=fl(claimable), itc_recoverable_if_fixed=fl(recover_inv + recover_reg),
            cost_borne=fl(cost_borne), reason_en=en, reason_mr=mr,
        )
        return assessment, claimable, recover_inv, recover_reg

    # ---- 3. liability -----------------------------------------------------
    def compute_liability(
        self, req: TaxAdviceRequest, contract: ContractTax, taxable: Decimal, eligible_itc: Decimal
    ) -> LiabilitySummary:
        output = ZERO if req.reverse_charge else d(contract.total_gst)
        utilised = min(output, eligible_itc)
        net = output - utilised
        carry = eligible_itc - utilised

        gst_tds = q(taxable * Decimal("0.02")) if req.client_is_government and taxable > Decimal("250000") else ZERO
        net_after_tds = max(ZERO, net - gst_tds)
        it_rate = Decimal("0.01") if req.vendor_entity_type == "individual_huf" else Decimal("0.02")
        it_tds = q(taxable * it_rate) if taxable > Decimal("30000") else ZERO

        notes_en = [
            "GST-TDS (2%) applies when a government deductor pays on a contract above ₹2.5 lakh (excluding GST); "
            "it is credited to your electronic cash ledger and can offset GST payable.",
            "Income-tax TDS u/s 194C is estimated at 1% (individual/HUF) or 2% (others) on the value excluding GST "
            "when GST is shown separately; check applicable thresholds and the PAN-based rate with your CA.",
        ]
        notes_mr = [
            "सरकारी विभागाकडून ₹2.5 लाखांपेक्षा जास्त (GST वगळून) कराराच्या payment वर 2% GST-TDS कापला जातो; "
            "तो आपल्या electronic cash ledger मध्ये जमा होतो आणि देय GST मधून वजा करता येतो.",
            "कलम 194C अंतर्गत आयकर TDS अंदाजे 1% (वैयक्तिक/HUF) किंवा 2% (इतर) आहे (GST स्वतंत्र दाखवल्यास GST वगळून); "
            "मर्यादा व PAN नुसार दर CA कडून तपासा.",
        ]
        if req.reverse_charge:
            notes_en.append("Reverse charge: the recipient pays GST directly, so your output GST liability is nil.")
            notes_mr.append("रिव्हर्स चार्ज: GST थेट प्राप्तकर्ता भरतो, त्यामुळे आपली output GST देयता शून्य आहे.")
        return LiabilitySummary(
            output_gst=fl(output), itc_utilised=fl(utilised), net_gst_payable=fl(net),
            excess_itc_carry_forward=fl(carry), gst_tds_expected=fl(gst_tds),
            net_gst_payable_after_tds_credit=fl(net_after_tds), income_tax_tds_estimate=fl(it_tds),
            notes_en=notes_en, notes_mr=notes_mr,
        )

    # ---- 4. strategies ----------------------------------------------------
    def rule_strategies(
        self, req: TaxAdviceRequest, assessments: list[ExpenseAssessment], itc: ItcSummary,
        liability: LiabilitySummary, profit: ProfitEstimate,
    ) -> list[TaxStrategy]:
        out: list[TaxStrategy] = []
        no_inv = [a for a in assessments if a.itc_status == "NO_INVOICE"]
        unreg = [a for a in assessments if a.itc_status == "UNREGISTERED_SUPPLIER"]

        if no_inv:
            amt = format_inr(itc.lost_no_invoice)
            out.append(TaxStrategy(
                title_en="Collect valid tax invoices", title_mr="वैध कर बीजके मिळवा",
                detail_en=f"{len(no_inv)} expense line(s) have no tax invoice. Obtaining them can unlock up to {amt} of ITC.",
                detail_mr=f"{len(no_inv)} खर्चांसाठी कर बीजक नाही. ती मिळाल्यास {amt} पर्यंत ITC मिळू शकतो.",
                estimated_itc_impact=itc.lost_no_invoice,
            ))
        if unreg:
            amt = format_inr(itc.lost_unregistered_supplier)
            out.append(TaxStrategy(
                title_en="Buy from GST-registered suppliers", title_mr="GST नोंदणीकृत पुरवठादाराकडूनच खरेदी करा",
                detail_en=f"{len(unreg)} purchase(s) are from suppliers without a valid GSTIN. Shifting them to registered suppliers can recover up to {amt} of ITC.",
                detail_mr=f"{len(unreg)} खरेदी वैध GSTIN नसलेल्या पुरवठादारांकडून आहे. नोंदणीकृत पुरवठादाराकडे वळल्यास {amt} पर्यंत ITC परत मिळू शकतो.",
                estimated_itc_impact=itc.lost_unregistered_supplier,
            ))
        if itc.blocked_itc > 0:
            amt = format_inr(itc.blocked_itc)
            out.append(TaxStrategy(
                title_en="Do not claim blocked credit; price it into future bids",
                title_mr="अवरोधित ITC घेऊ नका; पुढील बोलीत त्याचा खर्च धरा",
                detail_en=f"{amt} of GST paid falls under Section 17(5) and cannot be claimed. Claiming it risks interest and penalty; include it as a cost when quoting.",
                detail_mr=f"{amt} GST कलम 17(5) अंतर्गत येतो व तो घेता येत नाही. तो घेतल्यास व्याज व दंड लागू शकतो; बोली लावताना त्याचा खर्च धरा.",
            ))
        if liability.gst_tds_expected > 0:
            amt = format_inr(liability.gst_tds_expected)
            out.append(TaxStrategy(
                title_en="Reconcile and use the GST-TDS credit", title_mr="GST-TDS क्रेडिटचा मेळ घाला व वापरा",
                detail_en=f"About {amt} may be deducted as GST-TDS by the department. Match it with GSTR-2A/GSTR-7A and use the cash-ledger credit against GST payable.",
                detail_mr=f"विभागाकडून सुमारे {amt} GST-TDS कापला जाऊ शकतो. GSTR-2A/GSTR-7A शी जुळवा आणि देय GST साठी cash ledger मधील क्रेडिट वापरा.",
            ))
        if liability.excess_itc_carry_forward > 0:
            amt = format_inr(liability.excess_itc_carry_forward)
            out.append(TaxStrategy(
                title_en="Excess ITC carries forward", title_mr="अतिरिक्त ITC पुढे नेता येतो",
                detail_en=f"Eligible ITC exceeds output GST by {amt}; no cash GST is due this period and the balance carries forward to the next return.",
                detail_mr=f"पात्र ITC output GST पेक्षा {amt} ने जास्त आहे; या कालावधीत रोख GST देय नाही व शिल्लक पुढील विवरणपत्रात जाईल.",
            ))
        if req.reverse_charge:
            out.append(TaxStrategy(
                title_en="Reverse charge applies - do not collect GST on the invoice",
                title_mr="रिव्हर्स चार्ज लागू - बीजकावर GST आकारू नका",
                detail_en="Mention 'Reverse charge: Yes' on the invoice. The recipient pays the tax; keep the recipient's RCM payment proof for your records.",
                detail_mr="बीजकावर 'Reverse charge: Yes' नमूद करा. कर प्राप्तकर्ता भरतो; त्याच्या RCM payment चा पुरावा ठेवा.",
            ))
        elif req.sac_code.startswith("9985"):
            out.append(TaxStrategy(
                title_en="Check whether reverse charge applies to your service",
                title_mr="आपल्या सेवेला रिव्हर्स चार्ज लागू आहे का ते तपासा",
                detail_en="Some manpower / security-personnel services supplied by non-corporate suppliers to registered recipients fall under reverse charge. Confirm with your CA before issuing the invoice.",
                detail_mr="नोंदणीकृत प्राप्तकर्त्याला बिगर-कॉर्पोरेट पुरवठादाराने दिलेल्या काही मनुष्यबळ/सुरक्षा सेवा रिव्हर्स चार्जमध्ये येतात. बीजक देण्यापूर्वी CA कडून खात्री करा.",
            ))
        if profit.estimated_margin < 0:
            out.append(TaxStrategy(
                title_en="Costs exceed the contract value", title_mr="खर्च कराराच्या मूल्यापेक्षा जास्त आहे",
                detail_en="Your listed expenses (including non-claimable GST) are higher than the taxable contract value. Review costs and pricing before executing the work.",
                detail_mr="आपले नमूद खर्च (न मिळणाऱ्या GST सह) कराराच्या करपात्र मूल्यापेक्षा जास्त आहेत. काम सुरू करण्यापूर्वी खर्च व दर तपासा.",
            ))
        out.append(TaxStrategy(
            title_en="Match ITC with GSTR-2B before filing", title_mr="विवरणपत्र भरण्यापूर्वी ITC चा GSTR-2B शी मेळ घाला",
            detail_en="Claim ITC only for invoices that appear in GSTR-2B, and claim it before the Section 16(4) deadline (30 November after the financial year end, or the annual return date if earlier).",
            detail_mr="फक्त GSTR-2B मध्ये दिसणाऱ्या बीजकांवरच ITC घ्या आणि कलम 16(4) च्या मुदतीपूर्वी (आर्थिक वर्षानंतरचा 30 नोव्हेंबर, किंवा वार्षिक विवरणपत्राची तारीख जर आधी असेल) घ्या.",
        ))
        out.append(TaxStrategy(
            title_en="Issue the invoice on time", title_mr="बीजक वेळेत द्या",
            detail_en="For services, issue the tax invoice within 30 days of the date of supply (Rule 47) to avoid penalty and delayed ITC for your client.",
            detail_mr="सेवांसाठी पुरवठ्याच्या तारखेपासून 30 दिवसांत कर बीजक द्या (नियम 47), जेणेकरून दंड व क्लायंटचा ITC उशिरा होणे टळेल.",
        ))
        return out

    # ---- 5. invoice draft -------------------------------------------------
    def build_invoice(self, req: TaxAdviceRequest, contract: ContractTax) -> InvoiceDraft:
        inv_date = req.invoice_date or now_ist().date()
        fy = financial_year(inv_date)
        number = req.invoice_number or f"INV/{fy}/{uuid.uuid4().hex[:6].upper()}"
        description = req.service_description or (f"Services under tender {req.tender_id}" if req.tender_id else "Contract services")
        taxable = d(contract.taxable_value)
        notes = ["DRAFT - review with your CA before issuing.", "Invoice must be issued within 30 days of the date of supply."]
        if req.reverse_charge:
            notes.append("Reverse charge: Yes - tax is payable by the recipient; no tax is collected on this invoice.")
        if not valid_gstin(req.client_gstin):
            notes.append("Recipient GSTIN missing/invalid: add it so the invoice is reported as B2B in GSTR-1.")
        if not valid_gstin(req.vendor_gstin):
            notes.append("Your GSTIN is missing/invalid: it is mandatory on a GST tax invoice.")
        shown = (lambda v: 0.0) if req.reverse_charge else (lambda v: v)
        line = {
            "description": description, "sac": req.sac_code, "quantity": 1,
            "taxable_value": contract.taxable_value, "gst_rate": contract.gst_rate,
            "cgst": shown(contract.cgst), "sgst": shown(contract.sgst), "igst": shown(contract.igst),
        }
        return InvoiceDraft(
            invoice_number=number, invoice_date=inv_date.isoformat(), financial_year=fy,
            supplier={"name": req.vendor_name, "gstin": req.vendor_gstin, "state": contract.supplier_state},
            recipient={"name": req.client_name, "gstin": req.client_gstin},
            place_of_supply=contract.place_of_supply, supply_type=contract.supply_type,
            reverse_charge=req.reverse_charge, line_items=[line],
            totals={
                "taxable_value": contract.taxable_value, "cgst": shown(contract.cgst), "sgst": shown(contract.sgst),
                "igst": shown(contract.igst), "invoice_total": contract.invoice_total,
            },
            amount_in_words=rupees_in_words(d(contract.invoice_total)), notes=notes,
        )

    # ---- 6. CA pack -------------------------------------------------------
    def build_ca_pack(
        self, req: TaxAdviceRequest, contract: ContractTax, invoice: InvoiceDraft,
        assessments: list[ExpenseAssessment], itc: ItcSummary, liability: LiabilitySummary,
    ) -> dict[str, Any]:
        inv_date = date.fromisoformat(invoice.invoice_date)
        eligible_rows = [
            {"description": a.description, "category": a.category, "taxable_value": a.taxable_value, "itc": a.itc_claimable}
            for a in assessments if a.itc_status == "ELIGIBLE"
        ]
        blocked_rows = [
            {"description": a.description, "category": a.category, "gst": a.gst_amount, "status": a.itc_status,
             "reason": a.reason_en, "recoverable_if_fixed": a.itc_recoverable_if_fixed}
            for a in assessments if a.itc_status in ("BLOCKED", "NO_INVOICE", "UNREGISTERED_SUPPLIER")
        ]
        collect = [f"Tax invoice for: {a.description}" for a in assessments if a.itc_status == "NO_INVOICE"]
        collect += [f"Supplier GSTIN / registration proof for: {a.description}" for a in assessments if a.itc_status == "UNREGISTERED_SUPPLIER"]
        collect += [
            "Work order / contract copy and tender acknowledgement",
            "Signed copy of the tax invoice issued to the client",
            "GST-TDS certificate (GSTR-7A) and TDS certificate (Form 16A) from the department, when issued",
            "Bank statement showing payments to suppliers (180-day check)",
            "EPF / ESIC challans and wage register for the period",
        ]
        shown = (lambda v: 0.0) if req.reverse_charge else (lambda v: v)
        return {
            "period": f"{inv_date:%m-%Y}",
            "financial_year": invoice.financial_year,
            "gstr1_b2b": [{
                "recipient_gstin": req.client_gstin, "recipient_name": req.client_name,
                "invoice_number": invoice.invoice_number, "invoice_date": invoice.invoice_date,
                "place_of_supply": contract.place_of_supply, "reverse_charge": "Y" if req.reverse_charge else "N",
                "taxable_value": contract.taxable_value, "rate": contract.gst_rate,
                "igst": shown(contract.igst), "cgst": shown(contract.cgst), "sgst": shown(contract.sgst),
                "invoice_value": contract.invoice_total,
            }],
            "gstr3b": {
                "table_3_1_a_outward_taxable_supplies": {
                    "taxable_value": contract.taxable_value, "igst": shown(contract.igst),
                    "cgst": shown(contract.cgst), "sgst": shown(contract.sgst),
                },
                "table_4_a_5_all_other_itc": {
                    "total_eligible_itc": itc.eligible_itc,
                    "note": "Split by IGST / CGST / SGST from the individual supplier invoices as per GSTR-2B.",
                },
                "net_gst_payable": liability.net_gst_payable,
                "excess_itc_carry_forward": liability.excess_itc_carry_forward,
            },
            "itc_register_eligible": eligible_rows,
            "blocked_or_ineligible_register": blocked_rows,
            "documents_to_collect": collect,
            "reconciliation_checklist": [
                "Match purchase invoices with GSTR-2B and claim only matching ITC.",
                "Confirm every supplier was paid within 180 days of the invoice date.",
                "Confirm HSN/SAC and GST rate on each purchase invoice.",
                "Reconcile GST-TDS credit in the cash ledger with GSTR-7A.",
                "Verify RCM applicability for the supplies you made and received.",
            ],
        }

    # ---- 7. AI narrative --------------------------------------------------
    async def ai_narrative(
        self, req: TaxAdviceRequest, resp: TaxAdviceResponse
    ) -> Optional[AiNarrative]:
        try:
            llm = get_llm()
            facts = {
                "contract": resp.contract.model_dump(),
                "itc": resp.itc.model_dump(),
                "liability": resp.liability.model_dump(exclude={"notes_en", "notes_mr"}),
                "profit": resp.profit.model_dump(),
                "expense_statuses": [{"item": a.description, "category": a.category, "status": a.itc_status} for a in resp.expense_assessment],
                "client_is_government": req.client_is_government,
                "sac_code": req.sac_code,
                "existing_strategy_titles": [s.title_en for s in resp.strategies],
            }
            prompt = ChatPromptTemplate.from_messages([("system", NARRATIVE_SYSTEM), ("human", NARRATIVE_HUMAN)])
            chain = prompt | llm.with_structured_output(AiNarrative, method="function_calling")
            out = await chain.ainvoke({"facts": json.dumps(facts, ensure_ascii=False)})
            return out if isinstance(out, AiNarrative) else AiNarrative.model_validate(out)
        except LLMUnavailableError:
            return None
        except Exception:
            logger.exception("Tax narrative LLM call failed; using template summary")
            return None

    @staticmethod
    def template_summary(resp: TaxAdviceResponse) -> tuple[str, str]:
        c, i, liab = resp.contract, resp.itc, resp.liability
        en = (
            f"On a taxable contract value of {format_inr(c.taxable_value)}, GST @{c.gst_rate:g}% is {format_inr(c.total_gst)}"
            f"{' (payable by the recipient under reverse charge)' if c.reverse_charge else ''}. "
            f"Eligible ITC is {format_inr(i.eligible_itc)}, so net GST payable is {format_inr(liab.net_gst_payable)}"
            f"{', with ' + format_inr(liab.excess_itc_carry_forward) + ' ITC carried forward' if liab.excess_itc_carry_forward else ''}. "
            f"Estimated margin before income tax is {format_inr(resp.profit.estimated_margin)} ({resp.profit.estimated_margin_percent:.1f}%)."
        )
        mr = (
            f"{format_inr(c.taxable_value)} करपात्र कराराच्या मूल्यावर {c.gst_rate:g}% GST {format_inr(c.total_gst)} आहे"
            f"{' (रिव्हर्स चार्जमध्ये प्राप्तकर्ता भरतो)' if c.reverse_charge else ''}. "
            f"पात्र ITC {format_inr(i.eligible_itc)} असल्याने निव्वळ देय GST {format_inr(liab.net_gst_payable)} आहे"
            f"{', व ' + format_inr(liab.excess_itc_carry_forward) + ' ITC पुढे नेला जाईल' if liab.excess_itc_carry_forward else ''}. "
            f"आयकरपूर्व अंदाजित नफा {format_inr(resp.profit.estimated_margin)} ({resp.profit.estimated_margin_percent:.1f}%) आहे."
        )
        return en, mr

    # ---- public entry point -----------------------------------------------
    async def advise(self, req: TaxAdviceRequest) -> TaxAdviceResponse:
        warnings: list[str] = []

        contract, taxable = self.compute_contract(req)

        assessments: list[ExpenseAssessment] = []
        eligible = recover_inv = recover_reg = blocked = total_gst_exp = total_cost = ZERO
        for item in req.expense_breakdown:
            a, claimable, r_inv, r_reg = self.assess_expense(item)
            assessments.append(a)
            eligible += claimable
            recover_inv += r_inv
            recover_reg += r_reg
            total_gst_exp += d(a.gst_amount)
            total_cost += d(a.cost_borne)
            if a.itc_status == "BLOCKED":
                blocked += d(a.gst_amount)

        itc = ItcSummary(
            eligible_itc=fl(eligible), blocked_itc=fl(blocked), lost_no_invoice=fl(recover_inv),
            lost_unregistered_supplier=fl(recover_reg), total_gst_on_expenses=fl(total_gst_exp),
        )
        liability = self.compute_liability(req, contract, taxable, eligible)
        margin = taxable - total_cost
        profit = ProfitEstimate(
            revenue_taxable=fl(taxable), total_cost=fl(total_cost), estimated_margin=fl(margin),
            estimated_margin_percent=float(q(margin / taxable * 100)) if taxable > 0 else 0.0,
        )

        if not req.expense_breakdown:
            warnings.append("No expense_breakdown supplied: ITC and margin are zero / not meaningful. Add expenses for ITC advice.")
        if req.vendor_gstin and not valid_gstin(req.vendor_gstin):
            warnings.append("vendor_gstin does not look like a valid GSTIN; state code fell back to the default.")
        if req.client_gstin and not valid_gstin(req.client_gstin):
            warnings.append("client_gstin does not look like a valid GSTIN; place of supply may be wrong.")
        if req.gst_rate != 18.0:
            warnings.append(f"GST rate {req.gst_rate:g}% used instead of the standard 18%.")

        strategies = self.rule_strategies(req, assessments, itc, liability, profit)
        invoice = self.build_invoice(req, contract)
        ca_pack = self.build_ca_pack(req, contract, invoice, assessments, itc, liability)

        response = TaxAdviceResponse(
            tender_id=req.tender_id, contract=contract, itc=itc, liability=liability, profit=profit,
            expense_assessment=assessments, strategies=strategies, invoice_draft=invoice, ca_filing_pack=ca_pack,
            summary_en="", summary_mr="",
            disclaimer_en="Automated guidance based on standard GST rules; not professional advice. Rates, thresholds and notifications change - have your Chartered Accountant verify before filing.",
            disclaimer_mr="हे प्रमाणित GST नियमांवर आधारित स्वयंचलित मार्गदर्शन आहे; व्यावसायिक सल्ला नाही. दर, मर्यादा व अधिसूचना बदलतात - विवरणपत्र भरण्यापूर्वी आपल्या चार्टर्ड अकाउंटंटकडून खात्री करा.",
            ai_used=False, warnings=warnings,
        )

        narrative = await self.ai_narrative(req, response) if req.use_ai else None
        if narrative:
            response.summary_en, response.summary_mr = narrative.summary_en, narrative.summary_mr
            for s in narrative.extra_strategies[:3]:
                response.strategies.append(TaxStrategy(**s.model_dump(), source="ai"))
            response.ai_used = True
        else:
            response.summary_en, response.summary_mr = self.template_summary(response)
        return response
