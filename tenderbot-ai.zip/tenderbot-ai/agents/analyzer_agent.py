"""
agents/analyzer_agent.py - Tender document gap analysis.

Also owns the shared Pydantic schemas (TenderSummary, VendorProfile) used by the
scraper, the API layer and the communication agent.

Execution flow of `AnalyzerAgent.analyze(tender, vendor)`
---------------------------------------------------------
1. load_tender_text : merge the tender summary text with the text of the tender PDF
                      (downloaded with httpx, parsed with pypdf).
2. extract_requirements : GPT-4o (LangChain structured output) turns the text into a
                      typed `TenderRequirements` object. If the LLM is unavailable or
                      fails, a keyword heuristic is used and the report is flagged.
3. cross_check      : DETERMINISTIC comparison of requirements vs the vendor profile
                      (GST, EPF, turnover, experience, work certificates, expiry dates).
                      Eligibility decisions are never left to the LLM.
4. add_explanations : the LLM writes a plain-language English + Marathi summary from the
                      computed facts only; a template is used if the LLM is unavailable.
"""
from __future__ import annotations

import asyncio
import difflib
import io
import json
import logging
import re
from datetime import date, datetime
from typing import Literal, Optional

import httpx
from langchain_core.prompts import ChatPromptTemplate
from pydantic import BaseModel, Field, field_validator
from pypdf import PdfReader

from config import (
    LLMUnavailableError,
    format_inr,
    get_llm,
    normalize_phone,
    now_ist,
    settings,
    to_naive_ist,
)

logger = logging.getLogger(__name__)

Language = Literal["mr", "en", "both"]

# ---------------------------------------------------------------------------
# Shared schemas
# ---------------------------------------------------------------------------


class TenderSummary(BaseModel):
    """A tender as discovered by the scraper or supplied by the caller."""

    tender_id: str = Field(min_length=1, max_length=128)
    portal: str = "Unknown"
    title: str = ""
    department: Optional[str] = None
    location: Optional[str] = None
    category: Optional[str] = None
    estimated_value: Optional[float] = Field(default=None, ge=0)
    emd_amount: Optional[float] = Field(default=None, ge=0)
    published_date: Optional[datetime] = None
    deadline: Optional[datetime] = None
    url: Optional[str] = None
    pdf_url: Optional[str] = None
    summary_text: str = ""
    match_score: Optional[int] = None
    match_reasons: list[str] = Field(default_factory=list)


class VendorDocument(BaseModel):
    """One document the vendor has uploaded (GST certificate, EPF code, ...)."""

    doc_type: str = Field(min_length=1, description="e.g. 'GST Certificate', 'EPF', 'Turnover Certificate'")
    number: Optional[str] = None
    valid_until: Optional[date] = None
    verified: bool = True


class VendorProfile(BaseModel):
    """Vendor profile + uploaded documents. This is the `vendor_documents` API field."""

    vendor_name: str = Field(min_length=1, max_length=200)
    whatsapp_number: str
    voice_number: Optional[str] = None
    gstin: Optional[str] = None
    annual_turnover: Optional[float] = Field(default=None, ge=0, description="INR, latest FY or 3-year average")
    years_experience: Optional[int] = Field(default=None, ge=0)
    max_similar_work_value: Optional[float] = Field(default=None, ge=0, description="INR value of largest similar completed work")
    business_keywords: list[str] = Field(default_factory=list)
    preferred_states: list[str] = Field(default_factory=list)
    preferred_language: Language = "mr"
    documents: list[VendorDocument] = Field(default_factory=list)

    @field_validator("whatsapp_number")
    @classmethod
    def _normalize_whatsapp(cls, v: str) -> str:
        return normalize_phone(v)

    @field_validator("voice_number")
    @classmethod
    def _normalize_voice(cls, v: Optional[str]) -> Optional[str]:
        return normalize_phone(v) if v else v


# ---------------------------------------------------------------------------
# Document catalogue: canonical keys, English + Marathi labels, matching keywords
# ---------------------------------------------------------------------------
# Order matters: more specific entries come before generic ones (GST_RETURNS before GST_CERTIFICATE).
DOC_CATALOG: list[tuple[str, str, str, list[str]]] = [
    ("GST_RETURNS", "GST Returns (GSTR-1 / GSTR-3B)", "जीएसटी रिटर्न्स (GSTR-1 / GSTR-3B)",
     ["gstr", "gst return", "gst returns", "return filing"]),
    ("GST_CERTIFICATE", "GST Registration Certificate", "जीएसटी नोंदणी प्रमाणपत्र", ["gst", "gstin"]),
    ("PAN_CARD", "PAN Card", "पॅन कार्ड", ["pan", "pan card"]),
    ("EPF_REGISTRATION", "EPF Registration / Code", "ईपीएफ नोंदणी क्रमांक / प्रमाणपत्र",
     ["epf", "epfo", "pf", "provident fund"]),
    ("ESIC_REGISTRATION", "ESIC Registration", "ईएसआयसी नोंदणी प्रमाणपत्र", ["esic", "esi"]),
    ("TURNOVER_CERTIFICATE", "CA-certified Turnover Certificate", "सीए प्रमाणित वार्षिक उलाढाल प्रमाणपत्र",
     ["turnover", "annual turnover"]),
    ("FINANCIAL_STATEMENTS", "Balance Sheet / ITR / P&L (last 3 FY)", "ताळेबंद / आयटीआर / नफा-तोटा पत्रक (मागील ३ वर्षे)",
     ["balance sheet", "itr", "income tax return", "profit and loss", "financial statement", "audited"]),
    ("WORK_EXPERIENCE", "Work Experience / Completion Certificates", "कामाचा अनुभव / काम पूर्णत्व प्रमाणपत्रे",
     ["experience", "work order", "completion certificate", "performance certificate", "similar work", "work certificate"]),
    ("EMD", "EMD / Bid Security", "इसारा रक्कम (EMD) / बिड सिक्युरिटी",
     ["emd", "earnest money", "bid security", "bank guarantee"]),
    ("UDYAM", "Udyam (MSME) Registration", "उद्योग (Udyam) नोंदणी प्रमाणपत्र",
     ["udyam", "msme", "udyog aadhaar", "nsic"]),
    ("LABOUR_LICENCE", "Labour Licence (CLRA)", "कामगार परवाना (कंत्राटी कामगार कायदा)",
     ["labour licence", "labour license", "labor license", "clra", "contract labour"]),
    ("PSARA_LICENCE", "PSARA Licence (Security Agency)", "पीएसएआरए (PSARA) सुरक्षा एजन्सी परवाना",
     ["psara", "security agency licence", "security agency license"]),
    ("TRADE_LICENCE", "Shop Act / Trade Licence", "दुकान व आस्थापना / व्यापार परवाना",
     ["shop act", "trade licence", "trade license", "gumasta", "shop and establishment"]),
    ("SOLVENCY_CERTIFICATE", "Bank Solvency Certificate", "बँक सॉल्व्हन्सी प्रमाणपत्र", ["solvency"]),
    ("BANK_DETAILS", "Cancelled Cheque / Bank Details", "रद्द केलेला धनादेश / बँक तपशील",
     ["cancelled cheque", "canceled cheque", "bank detail", "bank details", "bank account"]),
    ("AFFIDAVIT_NON_BLACKLISTING", "Non-blacklisting Affidavit / Declaration", "काळ्या यादीत नसल्याचे प्रतिज्ञापत्र / घोषणापत्र",
     ["blacklist", "blacklisting", "blacklisted", "affidavit", "undertaking", "declaration"]),
    ("DSC", "Digital Signature Certificate (Class 3)", "डिजिटल सिग्नेचर प्रमाणपत्र (क्लास ३)",
     ["dsc", "digital signature"]),
    ("POWER_OF_ATTORNEY", "Power of Attorney / Authorisation Letter", "मुखत्यारपत्र / अधिकारपत्र",
     ["power of attorney", "poa", "authorisation letter", "authorization letter"]),
    ("PROFESSIONAL_TAX", "Professional Tax Registration", "व्यवसाय कर नोंदणी प्रमाणपत्र",
     ["professional tax", "ptrc", "ptec"]),
    ("CONTRACTOR_REGISTRATION", "Contractor Registration (PWD / Class)", "कंत्राटदार नोंदणी प्रमाणपत्र (PWD / वर्ग)",
     ["contractor registration", "registered contractor", "pwd registration", "enlistment"]),
    ("ISO_CERTIFICATE", "ISO Certification", "आयएसओ प्रमाणपत्र", ["iso"]),
    ("FIRM_CONSTITUTION", "Firm Constitution (Partnership Deed / Incorporation)", "भागीदारी करारनामा / निगमन प्रमाणपत्र",
     ["partnership deed", "moa", "aoa", "incorporation", "certificate of incorporation"]),
]
DOC_LABELS: dict[str, tuple[str, str]] = {k: (en, mr) for k, en, mr, _ in DOC_CATALOG}
CANONICAL_KEYS = [k for k, *_ in DOC_CATALOG]


def canonicalize_doc_type(raw: str) -> str:
    """Map free text ('GSTIN certificate', 'Udyog Aadhaar') to a canonical key or 'OTHER'."""
    text = re.sub(r"[^a-z0-9&]+", " ", raw.lower()).strip()
    if not text:
        return "OTHER"
    if raw.strip().upper() in DOC_LABELS:
        return raw.strip().upper()
    for key, _en, _mr, keywords in DOC_CATALOG:
        for kw in keywords:
            if re.search(rf"\b{re.escape(kw)}\b", text):
                return key
    return "OTHER"


# ---------------------------------------------------------------------------
# LLM output + report schemas
# ---------------------------------------------------------------------------


class RequiredDocument(BaseModel):
    doc_type: str = Field(description="Canonical key from the provided list, or OTHER")
    name: str = Field(description="Document name as written in the tender (English)")
    name_mr: str = Field(default="", description="Marathi name in Devanagari")
    mandatory: bool = True
    details: str = Field(default="", description="Validity / format conditions stated in the tender")


class TenderRequirements(BaseModel):
    required_documents: list[RequiredDocument] = Field(default_factory=list)
    min_annual_turnover: Optional[float] = Field(default=None, description="INR; convert lakh/crore")
    min_years_experience: Optional[int] = None
    min_similar_work_value: Optional[float] = Field(default=None, description="INR value of similar work required")
    emd_amount: Optional[float] = Field(default=None, description="INR")
    eligibility_notes: list[str] = Field(default_factory=list)
    extraction_confidence: Literal["high", "medium", "low"] = "medium"


class AnalysisExplanation(BaseModel):
    summary_en: str
    summary_mr: str = Field(description="Marathi, Devanagari script")
    next_steps_en: list[str] = Field(default_factory=list)
    next_steps_mr: list[str] = Field(default_factory=list)


class GapItem(BaseModel):
    doc_type: str
    name_en: str
    name_mr: str
    status: Literal["MISSING", "EXPIRED", "UNVERIFIED"]
    mandatory: bool = True
    detail_en: str = ""
    detail_mr: str = ""


class EligibilityIssue(BaseModel):
    code: str
    detail_en: str
    detail_mr: str


class GapReport(BaseModel):
    tender_id: str
    ready_for_submission: bool
    matched_documents: list[str] = Field(default_factory=list)
    missing_documents: list[GapItem] = Field(default_factory=list)       # mandatory gaps (blocking)
    optional_gaps: list[GapItem] = Field(default_factory=list)           # non-mandatory gaps
    eligibility_issues: list[EligibilityIssue] = Field(default_factory=list)
    checklist_en: str = ""
    checklist_mr: str = ""
    summary_en: str = ""
    summary_mr: str = ""
    next_steps_en: list[str] = Field(default_factory=list)
    next_steps_mr: list[str] = Field(default_factory=list)
    extraction_method: Literal["llm", "heuristic"] = "llm"
    extraction_confidence: Literal["high", "medium", "low"] = "medium"
    warnings: list[str] = Field(default_factory=list)


class AnalysisInputError(ValueError):
    """The tender has no usable text (no summary_text, unreadable PDF)."""


# ---------------------------------------------------------------------------
# Prompts (no literal curly braces - they would be parsed as template variables)
# ---------------------------------------------------------------------------
EXTRACTION_SYSTEM = (
    "You are a tender-document analyst for Indian government procurement (GeM, Mahatenders, CPPP). "
    "Read the tender text and extract ONLY what the text actually states: the documents a bidder must "
    "upload, minimum turnover, minimum years of experience, similar-work value and EMD. "
    "Rules: (1) Map each document to one of these canonical doc_type keys when it fits: {canonical_keys}; "
    "otherwise use OTHER and give a descriptive name. (2) Convert lakh/crore amounts to plain INR numbers. "
    "(3) Never invent requirements that are not in the text. (4) Put validity/format conditions in details. "
    "(5) Provide name_mr in simple Marathi (Devanagari); keep acronyms like GST, EPF, EMD in Latin letters. "
    "(6) Set extraction_confidence to low if the text looks truncated or has no eligibility section."
)
EXTRACTION_HUMAN = "TENDER TEXT:\n{tender_text}"

EXPLAIN_SYSTEM = (
    "You assist small Indian contractors. Using ONLY the facts JSON provided, write (a) a 2-3 sentence "
    "summary and (b) an ordered list of concrete next steps, once in English and once in Marathi "
    "(Devanagari, simple spoken style; keep acronyms such as GST, EPF, ESIC, EMD in Latin letters). "
    "Do not add requirements that are not in the facts and never promise the vendor will win the tender."
)
EXPLAIN_HUMAN = "FACTS JSON:\n{facts}"


# ---------------------------------------------------------------------------
# Agent
# ---------------------------------------------------------------------------
class AnalyzerAgent:
    """Reads tender text, extracts requirements and cross-checks them with the vendor profile."""

    MAX_PDF_BYTES = 25 * 1024 * 1024
    MAX_PDF_PAGES = 80
    MAX_TEXT_CHARS = 60_000

    # ---- step 1 -----------------------------------------------------------
    async def load_tender_text(self, tender: TenderSummary) -> tuple[str, list[str]]:
        """Combine summary metadata, summary text and (optionally) the tender PDF text."""
        warnings: list[str] = []
        header = [f"Tender ID: {tender.tender_id}", f"Portal: {tender.portal}"]
        if tender.title:
            header.append(f"Title: {tender.title}")
        if tender.department:
            header.append(f"Department: {tender.department}")
        if tender.estimated_value is not None:
            header.append(f"Estimated value: {format_inr(tender.estimated_value)}")
        if tender.emd_amount is not None:
            header.append(f"EMD: {format_inr(tender.emd_amount)}")
        if tender.deadline:
            header.append(f"Bid deadline: {tender.deadline:%d-%b-%Y %H:%M}")

        parts = ["\n".join(header)]
        if tender.summary_text.strip():
            parts.append(tender.summary_text.strip())

        if tender.pdf_url:
            try:
                pdf_text = await self._download_pdf_text(tender.pdf_url)
                if pdf_text.strip():
                    parts.append(pdf_text)
                else:
                    warnings.append("The tender PDF has no extractable text (it may be a scanned image); OCR is needed.")
            except Exception as exc:  # network / parsing problems must not kill the analysis
                logger.warning("PDF load failed for %s: %s", tender.tender_id, exc)
                warnings.append(f"Could not read the tender PDF ({type(exc).__name__}); analysis used the summary only.")

        text = "\n\n".join(parts)[: self.MAX_TEXT_CHARS]
        body_len = len(text) - len(parts[0])
        if body_len < 40:
            raise AnalysisInputError(
                "Tender has no usable text: provide summary_text or a readable pdf_url."
            )
        if body_len < 300:
            warnings.append("Tender text is very short; the document list may be incomplete. Attach the full PDF.")
        return text, warnings

    async def _download_pdf_text(self, url: str) -> str:
        async with httpx.AsyncClient(
            timeout=settings.scraper_timeout_seconds,
            follow_redirects=True,
            headers={"User-Agent": settings.scraper_user_agent},
        ) as client:
            resp = await client.get(url)
            resp.raise_for_status()
            if len(resp.content) > self.MAX_PDF_BYTES:
                raise ValueError("PDF larger than 25 MB")
            content = resp.content
        return await asyncio.to_thread(self._pdf_bytes_to_text, content)

    def _pdf_bytes_to_text(self, content: bytes) -> str:
        reader = PdfReader(io.BytesIO(content))
        pages = []
        for page in reader.pages[: self.MAX_PDF_PAGES]:
            pages.append(page.extract_text() or "")
        return "\n".join(pages)

    # ---- step 2 -----------------------------------------------------------
    async def extract_requirements(self, text: str) -> TenderRequirements:
        """LLM structured extraction (LangChain + GPT-4o)."""
        llm = get_llm()  # raises LLMUnavailableError without an API key
        prompt = ChatPromptTemplate.from_messages([("system", EXTRACTION_SYSTEM), ("human", EXTRACTION_HUMAN)])
        chain = prompt | llm.with_structured_output(TenderRequirements, method="function_calling")
        result = await chain.ainvoke({"canonical_keys": ", ".join(CANONICAL_KEYS), "tender_text": text})
        if not isinstance(result, TenderRequirements):
            result = TenderRequirements.model_validate(result)
        return result

    @staticmethod
    def heuristic_requirements(text: str) -> TenderRequirements:
        """Keyword fallback used when the LLM is unavailable. Low precision, flagged as such."""
        lowered = re.sub(r"[^a-z0-9&]+", " ", text.lower())
        docs: list[RequiredDocument] = []
        for key, en, mr, keywords in DOC_CATALOG:
            if any(re.search(rf"\b{re.escape(k)}\b", lowered) for k in keywords):
                docs.append(RequiredDocument(doc_type=key, name=en, name_mr=mr, mandatory=True))
        return TenderRequirements(required_documents=docs, extraction_confidence="low")

    # ---- step 3 -----------------------------------------------------------
    def cross_check(self, tender: TenderSummary, reqs: TenderRequirements, vendor: VendorProfile) -> GapReport:
        """Deterministic comparison - no LLM involved."""
        deadline = to_naive_ist(tender.deadline)
        reference_date = (deadline or now_ist()).date()

        vendor_docs = [(canonicalize_doc_type(d.doc_type), d) for d in vendor.documents]
        matched: list[str] = []
        mandatory_gaps: list[GapItem] = []
        optional_gaps: list[GapItem] = []
        seen: set[str] = set()

        for req in reqs.required_documents:
            key = req.doc_type if req.doc_type in DOC_LABELS else canonicalize_doc_type(f"{req.doc_type} {req.name}")
            dedupe_key = key if key != "OTHER" else f"OTHER::{req.name.strip().lower()}"
            if dedupe_key in seen:
                continue
            seen.add(dedupe_key)

            name_en = DOC_LABELS[key][0] if key in DOC_LABELS else (req.name or "Other document")
            name_mr = DOC_LABELS[key][1] if key in DOC_LABELS else (req.name_mr or req.name or "इतर कागदपत्र")

            doc = self._find_vendor_doc(key, req.name, vendor_docs)
            gap = self._gap_for(doc, key, name_en, name_mr, req.mandatory, reference_date)
            if gap is None:
                matched.append(name_en)
            elif req.mandatory:
                mandatory_gaps.append(gap)
            else:
                optional_gaps.append(gap)

        issues = self._eligibility_issues(tender, reqs, vendor, deadline)
        ready = not mandatory_gaps and not issues

        report = GapReport(
            tender_id=tender.tender_id,
            ready_for_submission=ready,
            matched_documents=matched,
            missing_documents=mandatory_gaps,
            optional_gaps=optional_gaps,
            eligibility_issues=issues,
            extraction_confidence=reqs.extraction_confidence,
        )
        if not reqs.required_documents:
            report.warnings.append("No document requirements were detected in the tender text; verify manually before approving.")
            report.ready_for_submission = False
        report.checklist_en = self.render_checklist(report, "en")
        report.checklist_mr = self.render_checklist(report, "mr")
        return report

    @staticmethod
    def _find_vendor_doc(key: str, req_name: str, vendor_docs: list[tuple[str, VendorDocument]]) -> Optional[VendorDocument]:
        if key != "OTHER":
            candidates = [d for canon, d in vendor_docs if canon == key]
        else:
            candidates = [
                d for canon, d in vendor_docs
                if difflib.SequenceMatcher(None, req_name.lower(), d.doc_type.lower()).ratio() >= 0.72
            ]
        if not candidates:
            return None
        # Prefer verified, then the longest validity.
        return sorted(candidates, key=lambda d: (d.verified, d.valid_until or date.max), reverse=True)[0]

    @staticmethod
    def _gap_for(
        doc: Optional[VendorDocument], key: str, name_en: str, name_mr: str, mandatory: bool, ref: date
    ) -> Optional[GapItem]:
        if doc is None:
            return GapItem(
                doc_type=key, name_en=name_en, name_mr=name_mr, status="MISSING", mandatory=mandatory,
                detail_en="Not found in your uploaded documents.",
                detail_mr="आपण अपलोड केलेल्या कागदपत्रांमध्ये आढळले नाही.",
            )
        if doc.valid_until and doc.valid_until < ref:
            return GapItem(
                doc_type=key, name_en=name_en, name_mr=name_mr, status="EXPIRED", mandatory=mandatory,
                detail_en=f"Expired on {doc.valid_until:%d-%b-%Y}; renew before the bid deadline.",
                detail_mr=f"मुदत {doc.valid_until:%d-%m-%Y} रोजी संपली; बोली मुदतीपूर्वी नूतनीकरण करा.",
            )
        if not doc.verified:
            return GapItem(
                doc_type=key, name_en=name_en, name_mr=name_mr, status="UNVERIFIED", mandatory=mandatory,
                detail_en="Uploaded but not verified yet.",
                detail_mr="अपलोड केले आहे पण अजून पडताळणी झालेली नाही.",
            )
        return None

    @staticmethod
    def _eligibility_issues(
        tender: TenderSummary, reqs: TenderRequirements, vendor: VendorProfile, deadline: Optional[datetime]
    ) -> list[EligibilityIssue]:
        issues: list[EligibilityIssue] = []

        if deadline and deadline < now_ist():
            issues.append(EligibilityIssue(
                code="DEADLINE_PASSED",
                detail_en=f"The bid deadline ({deadline:%d-%b-%Y %H:%M}) has already passed.",
                detail_mr=f"बोली सादर करण्याची मुदत ({deadline:%d-%m-%Y %H:%M}) संपली आहे.",
            ))

        if reqs.min_annual_turnover:
            need = format_inr(reqs.min_annual_turnover)
            if vendor.annual_turnover is None:
                issues.append(EligibilityIssue(
                    code="TURNOVER_UNKNOWN",
                    detail_en=f"Tender needs annual turnover of at least {need}, but your turnover is not provided.",
                    detail_mr=f"निविदेसाठी किमान {need} वार्षिक उलाढाल आवश्यक आहे, पण आपली उलाढाल नमूद केलेली नाही.",
                ))
            elif vendor.annual_turnover < reqs.min_annual_turnover:
                have = format_inr(vendor.annual_turnover)
                issues.append(EligibilityIssue(
                    code="TURNOVER_LOW",
                    detail_en=f"Tender needs annual turnover of at least {need}; your profile shows {have}.",
                    detail_mr=f"निविदेसाठी किमान {need} वार्षिक उलाढाल आवश्यक आहे; आपली उलाढाल {have} आहे.",
                ))

        if reqs.min_years_experience:
            n = reqs.min_years_experience
            if vendor.years_experience is None:
                issues.append(EligibilityIssue(
                    code="EXPERIENCE_UNKNOWN",
                    detail_en=f"Tender needs at least {n} years of experience, but your experience is not provided.",
                    detail_mr=f"निविदेसाठी किमान {n} वर्षांचा अनुभव आवश्यक आहे, पण आपला अनुभव नमूद केलेला नाही.",
                ))
            elif vendor.years_experience < n:
                issues.append(EligibilityIssue(
                    code="EXPERIENCE_LOW",
                    detail_en=f"Tender needs at least {n} years of experience; your profile shows {vendor.years_experience}.",
                    detail_mr=f"निविदेसाठी किमान {n} वर्षांचा अनुभव आवश्यक आहे; आपला अनुभव {vendor.years_experience} वर्षे आहे.",
                ))

        if reqs.min_similar_work_value:
            need = format_inr(reqs.min_similar_work_value)
            if vendor.max_similar_work_value is None:
                issues.append(EligibilityIssue(
                    code="SIMILAR_WORK_UNKNOWN",
                    detail_en=f"Tender needs a completed similar work worth {need}, but none is recorded in your profile.",
                    detail_mr=f"निविदेसाठी {need} मूल्याचे समान काम पूर्ण केलेले असणे आवश्यक आहे, पण प्रोफाइलमध्ये नोंद नाही.",
                ))
            elif vendor.max_similar_work_value < reqs.min_similar_work_value:
                have = format_inr(vendor.max_similar_work_value)
                issues.append(EligibilityIssue(
                    code="SIMILAR_WORK_LOW",
                    detail_en=f"Tender needs a completed similar work worth {need}; your largest is {have}.",
                    detail_mr=f"निविदेसाठी {need} मूल्याचे समान काम आवश्यक आहे; आपले सर्वात मोठे काम {have} चे आहे.",
                ))
        return issues

    # ---- checklist rendering -----------------------------------------------
    @staticmethod
    def render_checklist(report: GapReport, lang: Literal["en", "mr"]) -> str:
        lines: list[str] = []
        for g in report.missing_documents + report.optional_gaps:
            tag = "" if g.mandatory else (" (optional)" if lang == "en" else " (ऐच्छिक)")
            if lang == "en":
                icon = "❌" if g.status == "MISSING" else "⚠️"
                lines.append(f"{icon} {g.name_en}{tag} - {g.detail_en}")
            else:
                icon = "❌" if g.status == "MISSING" else "⚠️"
                lines.append(f"{icon} {g.name_mr}{tag} - {g.detail_mr}")
        for issue in report.eligibility_issues:
            lines.append(f"🚫 {issue.detail_en if lang == 'en' else issue.detail_mr}")
        if not lines:
            lines.append("✅ All requirements are covered." if lang == "en" else "✅ सर्व आवश्यकता पूर्ण आहेत.")
        return "\n".join(lines)

    # ---- step 4 -----------------------------------------------------------
    async def add_explanations(self, report: GapReport, tender: TenderSummary, vendor: VendorProfile) -> GapReport:
        """LLM writes the EN/MR explanation from computed facts; template fallback if unavailable."""
        try:
            llm = get_llm()
            facts = {
                "tender_id": tender.tender_id,
                "tender_title": tender.title,
                "vendor_name": vendor.vendor_name,
                "ready_for_submission": report.ready_for_submission,
                "missing_or_invalid_mandatory_documents": [
                    {"name": g.name_en, "status": g.status, "detail": g.detail_en} for g in report.missing_documents
                ],
                "eligibility_issues": [i.detail_en for i in report.eligibility_issues],
                "documents_already_in_order": report.matched_documents,
            }
            prompt = ChatPromptTemplate.from_messages([("system", EXPLAIN_SYSTEM), ("human", EXPLAIN_HUMAN)])
            chain = prompt | llm.with_structured_output(AnalysisExplanation, method="function_calling")
            out = await chain.ainvoke({"facts": json.dumps(facts, ensure_ascii=False)})
            if not isinstance(out, AnalysisExplanation):
                out = AnalysisExplanation.model_validate(out)
            report.summary_en, report.summary_mr = out.summary_en, out.summary_mr
            report.next_steps_en, report.next_steps_mr = out.next_steps_en, out.next_steps_mr
        except Exception as exc:  # LLMUnavailableError, network, validation ... all degrade gracefully
            if not isinstance(exc, LLMUnavailableError):
                logger.warning("Explanation LLM failed, using template: %s", exc)
            self._template_explanation(report)
        return report

    @staticmethod
    def _template_explanation(report: GapReport) -> None:
        n = len(report.missing_documents) + len(report.eligibility_issues)
        tid = report.tender_id
        if report.ready_for_submission:
            report.summary_en = f"All mandatory requirements for tender {tid} are covered. You can approve bid submission."
            report.summary_mr = f"निविदा {tid} साठी सर्व आवश्यक कागदपत्रे व पात्रता अटी पूर्ण आहेत. आपण बोली सादर करण्यास मंजुरी देऊ शकता."
        else:
            report.summary_en = f"{n} item(s) need attention before tender {tid} can be submitted."
            report.summary_mr = f"निविदा {tid} सादर करण्यापूर्वी {n} गोष्टींची पूर्तता करणे आवश्यक आहे."
        report.next_steps_en = [
            f"{'Upload' if g.status == 'MISSING' else 'Renew / verify'}: {g.name_en}" for g in report.missing_documents
        ] + [i.detail_en for i in report.eligibility_issues]
        report.next_steps_mr = [
            f"{g.name_mr} {'अपलोड करा' if g.status == 'MISSING' else 'नूतनीकरण / पडताळणी करा'}" for g in report.missing_documents
        ] + [i.detail_mr for i in report.eligibility_issues]

    # ---- public entry point -------------------------------------------------
    async def analyze(self, tender: TenderSummary, vendor: VendorProfile) -> GapReport:
        text, warnings = await self.load_tender_text(tender)

        method: Literal["llm", "heuristic"] = "llm"
        try:
            reqs = await self.extract_requirements(text)
        except Exception as exc:
            if not isinstance(exc, LLMUnavailableError):
                logger.exception("LLM extraction failed for %s", tender.tender_id)
            reqs = self.heuristic_requirements(text)
            method = "heuristic"
            warnings.append(
                "AI extraction was unavailable, so a keyword scan was used. Results are approximate; verify against the tender PDF."
            )

        # Values stated in the structured tender fields win over (or fill gaps in) the LLM output.
        if tender.emd_amount and not reqs.emd_amount:
            reqs.emd_amount = tender.emd_amount

        report = self.cross_check(tender, reqs, vendor)
        report.extraction_method = method
        report.warnings = warnings + report.warnings
        if method == "heuristic":
            report.extraction_confidence = "low"
        report = await self.add_explanations(report, tender, vendor)
        return report
