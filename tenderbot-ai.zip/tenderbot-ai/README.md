# TenderBot AI - Agentic Tender Hunter & Tax Assistant

Backend for Indian contractors, MSMEs, labour/security agencies and civil vendors.
Python 3.11+, FastAPI, Pydantic v2, LangChain (GPT-4o), Twilio (WhatsApp + Voice), SQLAlchemy.

## What it does

| Stage | Agent | What happens |
|-------|-------|--------------|
| 1. Discover | `scraper_agent.py` | Pulls latest tenders from Mahatenders, CPPP eProcurement and GeM, de-duplicates, scores them against the vendor profile (keywords, state, turnover fit, deadline). |
| 2. Gap analysis | `analyzer_agent.py` | Reads the tender text/PDF, extracts required documents + turnover/experience rules (GPT-4o structured output), then compares them **deterministically** with the vendor's GST, EPF, ESIC, turnover, work certificates, expiry dates. Explanations in English and Marathi. |
| 3. Approval | `communication_agent.py` | WhatsApp checklist, then a Twilio voice call (Marathi/English, keypad or speech) and a WhatsApp YES/NO prompt: *"All docs are ready. Should I submit the bid of ₹X for Tender ID Y?"* |
| 4. Tax | `tax_agent.py` | After award: 18% GST (CGST+SGST or IGST), ITC eligibility per expense (Sec 17(5) blocks, missing invoices, unregistered suppliers), GST-TDS/income-tax TDS estimates, margin, invoice draft, CA filing pack. |

All amounts are computed in code with `Decimal`. The LLM only extracts text and writes explanations; it never decides eligibility or does arithmetic.

## Project layout

```
tenderbot-ai/
├── README.md
├── requirements.txt
├── .env.example
├── config.py            settings + shared helpers (phone, INR, IST time, LLM factory)
├── database.py          SQLAlchemy models (vendors, tenders, analyses, approvals, tax records)
├── agents/
│   ├── __init__.py
│   ├── scraper_agent.py        portals, matching, bid-package preparation
│   ├── analyzer_agent.py       schemas, PDF reading, LLM extraction, gap analysis
│   ├── communication_agent.py  Twilio WhatsApp + voice, YES/NO parsing
│   └── tax_agent.py            GST / ITC / invoice / CA pack
└── main.py              FastAPI app and the approval state machine
```

## Quick start

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env            # fill in keys
uvicorn main:app --reload --port 8000
```

Interactive docs: `http://localhost:8000/docs`.

For local testing without portal access set `SCRAPER_MODE=mock`. Without `OPENAI_API_KEY` the analyzer falls back to a keyword scan (flagged `extraction_method: "heuristic"`) and the tax agent returns template summaries; all numbers are unaffected.

### Twilio setup

1. Expose the app over HTTPS (`ngrok http 8000`) and set `PUBLIC_BASE_URL` to that URL. Signature validation uses this exact URL.
2. WhatsApp: in the Twilio console set **"When a message comes in"** to `POST {PUBLIC_BASE_URL}/whatsapp-webhook`. The sandbox (`+14155238886`) needs each vendor to send the join code first.
3. Voice: buy a number that can call India (`TWILIO_VOICE_FROM`) and enable India in Geo Permissions. The call's `<Gather>` posts to `/voice-response` automatically (no console setting needed).
4. Marathi TTS/STT: the code uses `Google.mr-IN-Standard-A` and `mr-IN`. Confirm these are available on your account; change `TWILIO_VOICE_MARATHI` if not. Keypad (1 = yes, 2 = no) always works as a fallback.
5. **Business-initiated WhatsApp messages outside the 24-hour window require an approved template.** For real YES/NO buttons create a Content API *quick-reply* template with body variables `{{1}}` tender id, `{{2}}` amount, `{{3}}` vendor name and two buttons whose ids are `YES` and `NO`; put its SID in `TWILIO_APPROVAL_CONTENT_SID`. Without it the bot sends a plain text prompt (works only inside an open session).

## API

| Method | Path | Purpose |
|--------|------|---------|
| GET | `/` | Health check and integration status |
| POST | `/analyze-tender` | Gap analysis + WhatsApp checklist |
| POST | `/request-submit-approval` | Voice call + WhatsApp approval prompt |
| POST | `/whatsapp-webhook` | Twilio inbound WhatsApp (YES/NO) |
| POST | `/get-tax-advice` | GST, ITC strategies, invoice draft, CA pack |
| POST | `/scan-tenders` | *(extra)* discover and rank tenders, optional alerts/monitoring |
| POST | `/voice-response` | *(extra, Twilio callback)* keypad/speech answer from the call |

### Example: analyze a tender

```bash
curl -X POST localhost:8000/analyze-tender -H 'content-type: application/json' -d '{
  "tender_summary": {
    "tender_id": "2026_PWD_123456_1",
    "portal": "Mahatenders",
    "title": "Security guard services, Pune Civil Hospital",
    "estimated_value": 4800000,
    "deadline": "2026-10-30T17:00:00",
    "summary_text": "Bidders must upload GST registration, PAN, EPF and ESIC registration, PSARA licence, CA-certified turnover certificate (minimum annual turnover Rs 20 lakh), 3 years experience and a non-blacklisting affidavit."
  },
  "vendor_documents": {
    "vendor_name": "Shree Security Services",
    "whatsapp_number": "+919876543210",
    "annual_turnover": 3500000,
    "years_experience": 5,
    "preferred_language": "both",
    "documents": [
      {"doc_type": "GST Certificate", "number": "27ABCDE1234F1Z5"},
      {"doc_type": "PAN"},
      {"doc_type": "EPF", "number": "PUPUN1234567"}
    ]
  }
}'
```

### Example: ask for approval once documents are complete

```bash
curl -X POST localhost:8000/request-submit-approval -H 'content-type: application/json' -d '{
  "tender_id": "2026_PWD_123456_1",
  "bid_amount": 4650000,
  "vendor_whatsapp_number": "+919876543210"
}'
```

The vendor then answers on the call (press 1 / 2, or say *होय* / *नाही* / yes / no) or on WhatsApp. The first valid answer wins; later answers receive "already processed".

### Example: tax advice

```bash
curl -X POST localhost:8000/get-tax-advice -H 'content-type: application/json' -d '{
  "contract_amount": 4650000,
  "vendor_name": "Shree Security Services",
  "vendor_gstin": "27ABCDE1234F1Z5",
  "client_name": "Public Health Department",
  "client_gstin": "27AAAGP0001A1Z5",
  "expense_breakdown": [
    {"description": "Uniforms", "category": "uniforms", "amount": 250000, "supplier_gstin": "27AAACU1234B1Z9"},
    {"description": "Guard wages", "category": "labour_wages", "amount": 2900000},
    {"description": "Torches and radios", "category": "equipment", "amount": 120000, "has_tax_invoice": false},
    {"description": "Staff lunch", "category": "food", "amount": 40000, "supplier_gstin": "27AAACR1234C1Z1"}
  ]
}'
```

## Safety design for autonomous approval

- Approval can only be requested when the stored analysis for that vendor + tender is **ready**, the deadline is in the future, and no other request is pending.
- Twilio webhooks are rejected without a valid `X-Twilio-Signature` (`TWILIO_VALIDATE_SIGNATURE=true`).
- The reply parser is conservative: any "no" token wins, long free-text replies are ignored, and only `PENDING`, unexpired requests can transition.
- Requests expire after `APPROVAL_TTL_MINUTES`; an expired request is never executed.

## Known limits (read before production)

1. **Portal submission is assisted, not fully automatic.** Submitting on Mahatenders/GeM/CPPP needs the vendor's Class-3 DSC token and CAPTCHA/OTP steps. After a YES, `AssistedSubmitter` builds the bid package and step list and WhatsApps the vendor to complete the DSC-signed step; status becomes `SUBMISSION_READY`, never `SUBMITTED`. Implement `PortalSubmitter` in `scraper_agent.py` if you have a compliant DSC-enabled automation.
2. **Scrapers need upkeep.** GePNIC table markup and GeM's JSON endpoint change without notice and may sit behind CAPTCHAs. Per-portal errors are returned in `portal_status`. Check each portal's terms of use and robots policy, keep request rates low, and prefer official feeds/APIs where available.
3. **Tender PDFs that are scans** have no extractable text; add OCR (e.g. `ocrmypdf`) before analysis.
4. **Tax output is decision support.** Rates, thresholds, RCM notifications and blocked-credit rules change. Treat the invoice draft and CA pack as inputs for a Chartered Accountant, who must verify before filing.
5. Marathi text is generated and templated; have a native speaker review the voice scripts before launch.

## Production checklist

- Switch `DATABASE_URL` to Postgres and add Alembic migrations.
- Put the app behind HTTPS and keep `TWILIO_VALIDATE_SIGNATURE=true`.
- Protect `/analyze-tender`, `/request-submit-approval`, `/scan-tenders` and `/get-tax-advice` with your own auth (API key / JWT); only the two Twilio webhooks are meant to be public.
- Move the tender monitor to a proper worker (Celery/RQ) if you run several API instances.
