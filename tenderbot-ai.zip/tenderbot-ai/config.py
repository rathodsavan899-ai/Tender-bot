"""
config.py - central configuration plus small helpers shared by every module.

Execution flow
--------------
1. `settings` is created once at import time from environment variables / .env.
2. Every other module imports `settings` (never reads os.environ directly).
3. Shared helpers live here so agents do not import each other for trivia:
   - now_ist / to_naive_ist : all timestamps in the system are naive IST
   - normalize_phone        : any Indian phone format -> E.164
   - format_inr / speech_amount : money formatting for text and TTS
   - get_llm                : lazily-built, cached LangChain ChatOpenAI client
"""
from __future__ import annotations

import logging
import re
from datetime import datetime, timedelta, timezone
from decimal import ROUND_HALF_UP, Decimal
from functools import lru_cache
from typing import Literal, Optional

from pydantic_settings import BaseSettings, SettingsConfigDict

IST = timezone(timedelta(hours=5, minutes=30))


class Settings(BaseSettings):
    """All runtime configuration. Field names map to UPPER_CASE env vars."""

    model_config = SettingsConfigDict(
        env_file=".env", env_file_encoding="utf-8", extra="ignore", case_sensitive=False
    )

    # --- app ---
    app_name: str = "TenderBot AI"
    app_version: str = "1.0.0"
    environment: str = "development"
    log_level: str = "INFO"
    public_base_url: str = "http://localhost:8000"
    database_url: str = "sqlite:///./tenderbot.db"

    # --- OpenAI ---
    openai_api_key: str = ""
    openai_model: str = "gpt-4o"
    openai_timeout_seconds: int = 60

    # --- Twilio ---
    twilio_account_sid: str = ""
    twilio_auth_token: str = ""
    twilio_whatsapp_from: str = ""
    twilio_voice_from: str = ""
    twilio_approval_content_sid: str = ""
    twilio_validate_signature: bool = True
    twilio_voice_marathi: str = "Google.mr-IN-Standard-A"
    twilio_voice_english: str = "Google.en-IN-Standard-A"

    # --- approval flow ---
    default_country_code: str = "+91"
    approval_ttl_minutes: int = 120

    # --- scraper ---
    scraper_mode: Literal["live", "mock"] = "live"
    scraper_timeout_seconds: int = 30
    scraper_max_results_per_portal: int = 50
    scraper_user_agent: str = (
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/124.0 Safari/537.36 TenderBotAI/1.0"
    )
    mahatenders_url: str = (
        "https://mahatenders.gov.in/nicgep/app?page=FrontEndLatestActiveTenders&service=page"
    )
    cppp_url: str = (
        "https://eprocure.gov.in/eprocure/app?page=FrontEndLatestActiveTenders&service=page"
    )
    gem_base_url: str = "https://bidplus.gem.gov.in"
    match_score_threshold: int = 40
    enable_tender_monitor: bool = False
    monitor_interval_minutes: int = 60

    # --- tax ---
    default_gst_rate: float = 18.0

    @property
    def base_url(self) -> str:
        """PUBLIC_BASE_URL without a trailing slash."""
        return self.public_base_url.rstrip("/")

    @property
    def llm_configured(self) -> bool:
        return bool(self.openai_api_key)

    @property
    def twilio_configured(self) -> bool:
        return bool(self.twilio_account_sid and self.twilio_auth_token)


settings = Settings()


def configure_logging() -> None:
    """Idempotent logging setup, called from the FastAPI lifespan."""
    logging.basicConfig(
        level=getattr(logging, settings.log_level.upper(), logging.INFO),
        format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
    )


# ---------------------------------------------------------------------------
# Time helpers - the whole system stores naive datetimes in IST.
# ---------------------------------------------------------------------------
def now_ist() -> datetime:
    return datetime.now(IST).replace(tzinfo=None)


def to_naive_ist(dt: Optional[datetime]) -> Optional[datetime]:
    """Convert any datetime (aware or naive) to naive IST."""
    if dt is None:
        return None
    if dt.tzinfo is not None:
        return dt.astimezone(IST).replace(tzinfo=None)
    return dt


# ---------------------------------------------------------------------------
# Phone helpers
# ---------------------------------------------------------------------------
def normalize_phone(raw: str) -> str:
    """
    Normalise an Indian / international phone number to E.164 (+919876543210).
    Accepts "whatsapp:+91 98765-43210", "09876543210", "9876543210", "919876543210".
    Raises ValueError when the number cannot be interpreted.
    """
    if not raw:
        raise ValueError("phone number is empty")
    value = raw.strip()
    if value.lower().startswith("whatsapp:"):
        value = value[len("whatsapp:"):]
    value = re.sub(r"[\s\-().]", "", value)
    if value.startswith("+"):
        digits = value[1:]
        if not digits.isdigit() or not 8 <= len(digits) <= 15:
            raise ValueError(f"invalid phone number: {raw!r}")
        return "+" + digits
    if not value.isdigit():
        raise ValueError(f"invalid phone number: {raw!r}")
    if value.startswith("00"):
        value = value[2:]
        if 8 <= len(value) <= 15:
            return "+" + value
    cc = settings.default_country_code
    cc_digits = cc.lstrip("+")
    if len(value) == 10:
        return f"{cc}{value}"
    if len(value) == 11 and value.startswith("0"):
        return f"{cc}{value[1:]}"
    if value.startswith(cc_digits) and len(value) == len(cc_digits) + 10:
        return "+" + value
    raise ValueError(f"invalid phone number: {raw!r}")


# ---------------------------------------------------------------------------
# Money helpers
# ---------------------------------------------------------------------------
def format_inr(amount: float | Decimal | int | str) -> str:
    """Format with Indian digit grouping: 1234567.5 -> '₹12,34,567.50'."""
    n = Decimal(str(amount)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    sign = "-" if n < 0 else ""
    whole, frac = f"{abs(n):.2f}".split(".")
    if len(whole) > 3:
        head, tail = whole[:-3], whole[-3:]
        groups: list[str] = []
        while len(head) > 2:
            groups.insert(0, head[-2:])
            head = head[:-2]
        if head:
            groups.insert(0, head)
        whole = ",".join(groups + [tail])
    return f"{sign}₹{whole}" if frac == "00" else f"{sign}₹{whole}.{frac}"


def speech_amount(amount: float | Decimal | int | str) -> str:
    """Plain digits for text-to-speech (no currency symbol / commas)."""
    n = Decimal(str(amount)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    return f"{n:.0f}" if n == n.to_integral_value() else f"{n:.2f}"


# ---------------------------------------------------------------------------
# LLM factory
# ---------------------------------------------------------------------------
class LLMUnavailableError(RuntimeError):
    """Raised when the LLM is requested but OPENAI_API_KEY is not configured."""


@lru_cache(maxsize=1)
def get_llm():
    """Return a cached LangChain ChatOpenAI client (temperature 0 for determinism)."""
    if not settings.openai_api_key:
        raise LLMUnavailableError("OPENAI_API_KEY is not configured")
    from langchain_openai import ChatOpenAI  # imported lazily: keeps startup fast

    return ChatOpenAI(
        model=settings.openai_model,
        temperature=0,
        api_key=settings.openai_api_key,
        timeout=settings.openai_timeout_seconds,
        max_retries=2,
    )
