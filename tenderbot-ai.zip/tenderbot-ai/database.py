"""
database.py - SQLAlchemy 2.0 persistence layer (SQLite by default, Postgres-ready).

Tables
------
vendors          : contractor profile + notification preferences
tenders          : tenders discovered by the scraper or submitted for analysis
tender_analyses  : per (tender, vendor) document gap analysis result
approval_requests: one row per "Should I submit the bid?" conversation
tax_records      : audit trail of every GST advice request / response

Execution flow
--------------
FastAPI endpoints receive a Session through `get_db()` (one per request).
Background jobs (submission flow, tender monitor) use `session_scope()`.
"""
from __future__ import annotations

import enum
from contextlib import contextmanager
from datetime import datetime
from typing import Any, Iterator, Optional

from sqlalchemy import (
    JSON,
    Boolean,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
    UniqueConstraint,
    create_engine,
)
from sqlalchemy.orm import (
    DeclarativeBase,
    Mapped,
    Session,
    mapped_column,
    relationship,
    sessionmaker,
)

from config import now_ist, settings

_is_sqlite = settings.database_url.startswith("sqlite")
engine = create_engine(
    settings.database_url,
    connect_args={"check_same_thread": False} if _is_sqlite else {},
    pool_pre_ping=True,
)
SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)


class Base(DeclarativeBase):
    pass


class ApprovalStatus(str, enum.Enum):
    PENDING = "PENDING"                      # waiting for YES / NO
    APPROVED = "APPROVED"                    # vendor said YES, submission flow queued
    REJECTED = "REJECTED"                    # vendor said NO
    EXPIRED = "EXPIRED"                      # TTL elapsed before an answer
    FAILED = "FAILED"                        # notification or submission failed
    SUBMISSION_READY = "SUBMISSION_READY"    # bid package prepared, final DSC step pending
    SUBMITTED = "SUBMITTED"                  # portal confirmed submission


class Vendor(Base):
    __tablename__ = "vendors"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(200))
    whatsapp_number: Mapped[str] = mapped_column(String(32), unique=True, index=True)
    voice_number: Mapped[Optional[str]] = mapped_column(String(32), nullable=True)
    language: Mapped[str] = mapped_column(String(8), default="mr")
    monitoring_enabled: Mapped[bool] = mapped_column(Boolean, default=False)
    profile: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=now_ist)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=now_ist, onupdate=now_ist)


class Tender(Base):
    __tablename__ = "tenders"

    id: Mapped[int] = mapped_column(primary_key=True)
    tender_id: Mapped[str] = mapped_column(String(128), unique=True, index=True)
    portal: Mapped[str] = mapped_column(String(64), default="Unknown")
    title: Mapped[str] = mapped_column(Text, default="")
    data: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)  # full TenderSummary
    created_at: Mapped[datetime] = mapped_column(DateTime, default=now_ist)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=now_ist, onupdate=now_ist)


class TenderAnalysis(Base):
    __tablename__ = "tender_analyses"
    __table_args__ = (UniqueConstraint("tender_pk", "vendor_id", name="uq_analysis_tender_vendor"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    tender_pk: Mapped[int] = mapped_column(ForeignKey("tenders.id"), index=True)
    vendor_id: Mapped[int] = mapped_column(ForeignKey("vendors.id"), index=True)
    ready_for_submission: Mapped[bool] = mapped_column(Boolean, default=False)
    report: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=now_ist)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=now_ist, onupdate=now_ist)

    tender: Mapped["Tender"] = relationship()
    vendor: Mapped["Vendor"] = relationship()


class ApprovalRequest(Base):
    __tablename__ = "approval_requests"

    id: Mapped[int] = mapped_column(primary_key=True)
    tender_pk: Mapped[int] = mapped_column(ForeignKey("tenders.id"), index=True)
    vendor_id: Mapped[int] = mapped_column(ForeignKey("vendors.id"), index=True)
    bid_amount: Mapped[float] = mapped_column(Float)
    status: Mapped[str] = mapped_column(String(32), default=ApprovalStatus.PENDING.value, index=True)
    resolved_via: Mapped[Optional[str]] = mapped_column(String(16), nullable=True)  # whatsapp|voice
    decision_text: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    call_sid: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    whatsapp_sid: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    submission: Mapped[Optional[dict[str, Any]]] = mapped_column(JSON, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=now_ist)
    expires_at: Mapped[datetime] = mapped_column(DateTime)
    resolved_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)

    tender: Mapped["Tender"] = relationship()
    vendor: Mapped["Vendor"] = relationship()


class TaxRecord(Base):
    __tablename__ = "tax_records"

    id: Mapped[int] = mapped_column(primary_key=True)
    tender_id: Mapped[Optional[str]] = mapped_column(String(128), nullable=True, index=True)
    contract_amount: Mapped[float] = mapped_column(Float)
    request: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    result: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=now_ist)


def init_db() -> None:
    """Create all tables if they do not exist (call once at startup)."""
    Base.metadata.create_all(bind=engine)


def get_db() -> Iterator[Session]:
    """FastAPI dependency: one session per request, always closed."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@contextmanager
def session_scope() -> Iterator[Session]:
    """Transactional scope for background tasks: commit on success, rollback on error."""
    db = SessionLocal()
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()
